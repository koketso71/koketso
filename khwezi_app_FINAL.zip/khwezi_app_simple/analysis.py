# analysis.py
# The interactive data analysis page (Appendix A of the brief).
# QUESTIONS lists every question, the topic it belongs to and the permissions
# a user needs to see it. answer_question() works out the answer.

import pandas as pd
from settings import *
from core import (add_worker_columns, add_equipment_columns, add_risk_columns, build_alerts,
                  equipment_kpis, filter_period, recommendations)

HS = "Health and safety"
EQ = "Equipment"
IN = "Integrated safety and equipment"

# (id, topic, question, permissions needed)
QUESTIONS = [
    ("total_incidents", HS, "How many safety incidents occurred during the selected period?", ["Safety incidents"]),
    ("dept_incidents", HS, "Which department has the highest number of incidents?", ["Safety incidents"]),
    ("shift_incidents", HS, "Which shift records the most incidents?", ["Safety incidents"]),
    ("ppe", HS, "What percentage of workers comply with PPE requirements?", ["Worker safety data"]),
    ("near_misses", HS, "How many near misses have been recorded?", ["Worker safety data"]),
    ("incident_types", HS, "Which incident types occur most frequently?", ["Safety incidents"]),
    ("high_critical", HS, "How many incidents are classified as high or critical?", ["Safety incidents"]),
    ("dept_risk", HS, "Which departments have the highest safety risk?", ["Risk assessment"]),
    ("day_night", HS, "Is there an observable difference in incidents between day and night shifts?", ["Safety incidents", "Worker safety data"]),
    ("attention", HS, "Which safety conditions require immediate attention?", ["Safety incidents", "Worker safety data", "Risk assessment"]),

    ("highest_downtime", EQ, "Which equipment has the highest downtime?", ["Maintenance data"]),
    ("lowest_availability", EQ, "Which equipment has the lowest availability?", ["Maintenance data"]),
    ("highest_vibration", EQ, "Which equipment has the highest vibration?", ["Equipment data"]),
    ("highest_temperature", EQ, "Which equipment has the highest operating temperature?", ["Equipment data"]),
    ("most_alerts", EQ, "Which equipment has generated the most alerts?", ["Equipment data"]),
    ("needs_maintenance", EQ, "Which equipment requires maintenance?", ["Maintenance data"]),
    ("overdue", EQ, "Which equipment is overdue for maintenance?", ["Maintenance data"]),
    ("avg_availability", EQ, "What is the average equipment availability?", ["Maintenance data"]),
    ("type_downtime", EQ, "Which equipment type has the highest downtime?", ["Maintenance data"]),
    ("inspection", EQ, "Which equipment requires immediate inspection?", ["Equipment data"]),

    ("shift_association", IN, "Are safety incidents associated with particular shifts?", ["Safety incidents", "Worker safety data"]),
    ("risk_and_downtime", IN, "Which departments have both high safety risk and high equipment downtime?", ["Risk assessment", "Maintenance data"]),
    ("equipment_alerts", IN, "Which equipment contributes to the greatest number of alerts?", ["Equipment data", "Maintenance data"]),
    ("priority", IN, "Which equipment should receive maintenance priority?", ["Equipment data", "Maintenance data"]),
    ("causes", IN, "What are the most common causes of safety incidents?", ["Safety incidents"]),
    ("intervention", IN, "Which safety indicators require management intervention?", ["Safety incidents", "Worker safety data", "Risk assessment"]),
    ("pct_normal", IN, "What percentage of monitored equipment is operating normally?", ["Equipment data"]),
    ("critical_alerts", IN, "How many critical alerts are currently active?", ["Safety incidents", "Equipment data"]),
    ("areas", IN, "Which areas of the operation require the greatest attention?", ["Safety incidents", "Worker safety data", "Risk assessment", "Equipment data"]),
    ("recommendations", IN, "What recommendations can be generated from the monitoring results?", ["Safety incidents", "Equipment data"]),
]


def count_table(series, name):
    # Counts how often each value appears, largest first
    counts = series.value_counts()
    return pd.DataFrame({name: counts.index, "Count": counts.values})


def top_units(equipment, column, label, biggest_first, unit_text, noun):
    # Shows the 10 units with the highest (or lowest) value of one column
    top = equipment.sort_values(column, ascending=not biggest_first).head(10)
    table = pd.DataFrame({"Equipment": top["equipment_id"], "Type": top["equipment_type"], label: top[column]})
    first = table.iloc[0]
    if biggest_first:
        word = "highest"
    else:
        word = "lowest"
    headline = first["Equipment"] + " (" + first["Type"] + ") has the " + word + " " + noun + ": " + str(first[label]) + unit_text + "."
    chart = {"kind": "bar", "x": "Equipment", "y": label, "title": label}
    return headline, table, chart


def answer_question(question_id, data, days):
    # Returns (headline, table, chart). chart can be None.
    incidents = filter_period(data["incidents"], days)
    workers = add_worker_columns(data["workers"])
    equipment = add_equipment_columns(data["equipment"])
    risks = add_risk_columns(data["risks"])
    alerts = build_alerts(data)

    # ---------------- Health and safety ----------------
    if question_id == "total_incidents":
        table = pd.DataFrame({"Severity": SEVERITIES, "Count": [len(incidents[incidents["severity"] == s]) for s in SEVERITIES]})
        headline = str(len(incidents)) + " incidents were recorded in the selected period."
        return headline, table, {"kind": "bar", "x": "Severity", "y": "Count", "title": "Incidents by severity"}

    if question_id == "dept_incidents":
        table = count_table(incidents["department"], "Department")
        headline = table.iloc[0, 0] + " has the highest number of incidents (" + str(table.iloc[0, 1]) + ")."
        return headline, table, {"kind": "bar", "x": "Count", "y": "Department", "title": "Incidents by department", "h": True}

    if question_id == "shift_incidents":
        table = count_table(incidents["shift"], "Shift")
        headline = "The " + table.iloc[0, 0] + " shift records the most incidents (" + str(table.iloc[0, 1]) + ")."
        return headline, table, {"kind": "bar", "x": "Shift", "y": "Count", "title": "Incidents by shift"}

    if question_id == "ppe":
        compliant = len(workers[workers["ppe_compliance_pct"] >= PPE_TARGET]) / len(workers) * 100
        average = workers["ppe_compliance_pct"].mean()
        table = workers.groupby("department")["ppe_compliance_pct"].mean().round(1).reset_index()
        table.columns = ["Department", "Average PPE compliance (%)"]
        headline = (str(round(compliant, 1)) + "% of workers meet the " + str(round(PPE_TARGET)) + "% PPE compliance target. "
                    "Average PPE compliance is " + str(round(average, 1)) + "%.")
        return headline, table, {"kind": "bar", "x": "Department", "y": "Average PPE compliance (%)", "title": "PPE compliance by department"}

    if question_id == "near_misses":
        table = workers.groupby("department")["near_misses"].sum().reset_index()
        table.columns = ["Department", "Near misses"]
        table = table.sort_values("Near misses", ascending=False)
        headline = str(int(workers["near_misses"].sum())) + " near misses have been recorded."
        return headline, table, {"kind": "bar", "x": "Department", "y": "Near misses", "title": "Near misses by department"}

    if question_id == "incident_types":
        table = count_table(incidents["incident_type"], "Incident type")
        headline = "'" + table.iloc[0, 0] + "' is the most frequent incident type (" + str(table.iloc[0, 1]) + " incidents)."
        return headline, table, {"kind": "bar", "x": "Count", "y": "Incident type", "title": "Incidents by type", "h": True}

    if question_id == "high_critical":
        selected = incidents[incidents["severity"].isin(["High", "Critical"])]
        share = len(selected) / max(len(incidents), 1) * 100
        headline = (str(len(selected)) + " incidents are classified as High or Critical (" + str(round(share, 1))
                    + "% of incidents in the selected period).")
        table = selected[["incident_id", "date", "department", "incident_type", "severity", "status"]]
        return headline, table.sort_values("date", ascending=False), None

    if question_id == "dept_risk":
        rows = []
        for department in DEPARTMENTS:
            part = risks[risks["department"] == department]
            if len(part) > 0:
                high = len(part[part["classification"].isin(["High", "Critical"])])
                rows.append({"Department": department, "Average risk score": round(part["risk_score"].mean(), 1),
                             "High/Critical risks": high})
        table = pd.DataFrame(rows).sort_values(["High/Critical risks", "Average risk score"], ascending=False)
        first = table.iloc[0]
        headline = (first["Department"] + " has the highest safety risk (" + str(first["High/Critical risks"])
                    + " high/critical risks, average score " + str(first["Average risk score"]) + ").")
        return headline, table, {"kind": "bar", "x": "Department", "y": "Average risk score", "title": "Average risk score by department"}

    if question_id == "day_night":
        rows = []
        for shift in SHIFTS:
            number = len(incidents[incidents["shift"] == shift])
            people = len(workers[workers["shift"] == shift])
            rate = round(number / people * 10, 1) if people > 0 else 0
            rows.append({"Shift": shift, "Incidents": number, "Workers": people, "Incidents per 10 workers": rate})
        table = pd.DataFrame(rows)
        day_rate = table.loc[table["Shift"] == "Day", "Incidents per 10 workers"].iloc[0]
        night_rate = table.loc[table["Shift"] == "Night", "Incidents per 10 workers"].iloc[0]
        if night_rate > day_rate:
            word = "higher"
        else:
            word = "not higher"
        headline = ("Day shift: " + str(day_rate) + " incidents per 10 workers; night shift: " + str(night_rate)
                    + ". Night shift is " + word + ".")
        return headline, table, {"kind": "bar", "x": "Shift", "y": "Incidents per 10 workers", "title": "Incident rate by shift"}

    if question_id == "attention":
        table = alerts[(alerts["level"] == "CRITICAL") & (alerts["category"].isin(["Worker safety", "Incident", "Risk"]))]
        headline = str(len(table)) + " safety conditions need immediate attention (critical alerts)."
        return headline, table[["alert_id", "category", "subject", "parameter", "value", "status"]], None

    # ---------------- Equipment ----------------
    if question_id == "highest_downtime":
        return top_units(equipment, "downtime_h", "Downtime (h)", True, " h", "downtime")

    if question_id == "lowest_availability":
        return top_units(equipment, "availability_pct", "Availability (%)", False, "%", "availability")

    if question_id == "highest_vibration":
        return top_units(equipment, "vibration_mm_s", "Vibration (mm/s)", True, " mm/s", "vibration")

    if question_id == "highest_temperature":
        return top_units(equipment, "temperature_c", "Temperature (°C)", True, " °C", "operating temperature")

    if question_id == "most_alerts":
        return top_units(equipment, "alerts_30d", "Alerts (30 days)", True, " alerts", "number of alerts in the last 30 days")

    if question_id == "needs_maintenance":
        selected = equipment[equipment["needs_maintenance"]].sort_values("priority_score", ascending=False)
        headline = str(len(selected)) + " of " + str(len(equipment)) + " units require maintenance."
        return headline, selected[["equipment_id", "equipment_type", "service_state", "condition", "availability_pct", "priority"]], None

    if question_id == "overdue":
        selected = equipment[equipment["service_state"] == "Overdue"].sort_values("days_to_service")
        table = pd.DataFrame({
            "Equipment": selected["equipment_id"],
            "Type": selected["equipment_type"],
            "Service due": selected["next_service_due"].dt.strftime("%Y-%m-%d"),
            "Days overdue": -selected["days_to_service"],
        })
        return str(len(selected)) + " units are overdue for maintenance.", table, None

    if question_id == "avg_availability":
        table = equipment.groupby("equipment_type")["availability_pct"].mean().round(1).reset_index()
        table.columns = ["Equipment type", "Average availability (%)"]
        headline = ("Average equipment availability is " + str(round(equipment["availability_pct"].mean(), 1))
                    + "% (target " + str(round(LOW_AVAILABILITY)) + "%).")
        return headline, table, {"kind": "bar", "x": "Equipment type", "y": "Average availability (%)", "title": "Average availability by type"}

    if question_id == "type_downtime":
        table = equipment.groupby("equipment_type")["downtime_h"].sum().sort_values(ascending=False).reset_index()
        table.columns = ["Equipment type", "Total downtime (h)"]
        headline = table.iloc[0, 0] + " has the highest total downtime (" + str(round(table.iloc[0, 1])) + " h)."
        return headline, table, {"kind": "bar", "x": "Equipment type", "y": "Total downtime (h)", "title": "Downtime by equipment type"}

    if question_id == "inspection":
        selected = equipment[(equipment["condition"] == "Critical") & (equipment["maintenance_status"] != "Under maintenance")]
        if len(selected) == 1:
            headline = "1 unit requires immediate inspection."
        else:
            headline = str(len(selected)) + " units require immediate inspection."
        return headline, selected[["equipment_id", "equipment_type", "temperature_c", "vibration_mm_s", "condition_message"]], None

    # ---------------- Integrated ----------------
    if question_id == "shift_association":
        # chi-square test: are incidents spread across shifts like the workers are?
        total_incidents = len(incidents)
        rows = []
        chi_square = 0
        for shift in SHIFTS:
            observed = len(incidents[incidents["shift"] == shift])
            expected = len(workers[workers["shift"] == shift]) / len(workers) * total_incidents
            if expected > 0:
                chi_square = chi_square + (observed - expected) ** 2 / expected
            rows.append({"Shift": shift, "Observed incidents": observed, "Expected (by headcount)": round(expected, 1)})
        table = pd.DataFrame(rows)
        if chi_square > 5.99:
            verdict = "suggests incidents are associated with particular shifts"
        else:
            verdict = "does not show a statistically significant association"
        headline = "Chi-square = " + str(round(chi_square, 2)) + " (critical value 5.99 at 5%, 2 d.f.), which " + verdict + "."
        return headline, table, {"kind": "bar", "x": "Shift", "y": "Observed incidents", "title": "Observed incidents by shift"}

    if question_id == "risk_and_downtime":
        rows = []
        for department in DEPARTMENTS:
            risk_part = risks[risks["department"] == department]
            equipment_part = equipment[equipment["department"] == department]
            if len(risk_part) > 0 and len(equipment_part) > 0:
                rows.append({"Department": department,
                             "Average risk score": round(risk_part["risk_score"].mean(), 1),
                             "Downtime (h)": round(equipment_part["downtime_h"].sum(), 1),
                             "Average availability (%)": round(equipment_part["availability_pct"].mean(), 1)})
        table = pd.DataFrame(rows)
        risk_median = table["Average risk score"].median()
        downtime_median = table["Downtime (h)"].median()
        high_both = table[(table["Average risk score"] >= risk_median) & (table["Downtime (h)"] >= downtime_median)]
        names = ", ".join(list(high_both["Department"]))
        if names == "":
            names = "none"
        headline = "Departments above the median for both risk and downtime: " + names + "."
        chart = {"kind": "scatter", "x": "Average risk score", "y": "Downtime (h)", "label": "Department",
                 "title": "Safety risk versus equipment downtime"}
        return headline, table.sort_values("Downtime (h)", ascending=False), chart

    if question_id == "equipment_alerts":
        selected = alerts[alerts["category"].isin(["Equipment", "Maintenance"])]
        table = count_table(selected["subject"], "Equipment").head(10)
        table = table.rename(columns={"Count": "Active alerts"})
        headline = table.iloc[0, 0] + " contributes the most active alerts (" + str(table.iloc[0, 1]) + ")."
        return headline, table, {"kind": "bar", "x": "Equipment", "y": "Active alerts", "title": "Active alerts by equipment"}

    if question_id == "priority":
        top = equipment.sort_values("priority_score", ascending=False).head(10)
        table = top[["equipment_id", "equipment_type", "priority", "priority_score", "service_state", "condition", "availability_pct"]]
        headline = table.iloc[0, 0] + " should receive maintenance priority (score " + str(table.iloc[0, 3]) + ")."
        return headline, table, {"kind": "bar", "x": "equipment_id", "y": "priority_score", "title": "Maintenance priority score"}

    if question_id == "causes":
        table = count_table(incidents["cause"], "Cause")
        headline = "'" + table.iloc[0, 0] + "' is the most common cause (" + str(table.iloc[0, 1]) + " incidents)."
        return headline, table, {"kind": "bar", "x": "Count", "y": "Cause", "title": "Incident causes", "h": True}

    if question_id == "intervention":
        open_critical = len(incidents[(incidents["severity"] == "Critical") & (incidents["status"] != "Closed")])
        open_risks = len(risks[(risks["risk_score"] >= 10) & (risks["status"] != "Closed")])
        lti = len(incidents[incidents["lost_time_injury"] == "Yes"])
        ppe_average = round(workers["ppe_compliance_pct"].mean(), 1)
        tired = round(len(workers[workers["fatigue_level"] >= FATIGUE_HIGH]) / len(workers) * 100, 1)
        expired = round(len(workers[workers["training_status"] == "Expired"]) / len(workers) * 100, 1)

        # (indicator, value, target, does it need intervention?)
        rows = [
            ["Average PPE compliance (%)", ppe_average, ">= " + str(round(PPE_TARGET)), ppe_average < PPE_TARGET],
            ["Workers with high fatigue (%)", tired, "< 10", tired >= 10],
            ["Workers with expired training (%)", expired, "< 5", expired >= 5],
            ["Open critical incidents", open_critical, "0", open_critical > 0],
            ["Lost-time injuries (period)", lti, "0", lti > 0],
            ["Open High/Critical risks", open_risks, "0", open_risks > 0],
        ]
        count = 0
        for row in rows:
            if row[3]:
                count = count + 1
                row[3] = "Yes"
            else:
                row[3] = "No"
        table = pd.DataFrame(rows, columns=["Indicator", "Value", "Target", "Needs intervention"])
        headline = str(count) + " of " + str(len(rows)) + " safety indicators need management intervention."
        return headline, table, None

    if question_id == "pct_normal":
        k = equipment_kpis(data)
        table = count_table(equipment["condition"], "Condition").rename(columns={"Count": "Units"})
        headline = str(k["pct_normal"]) + "% of monitored equipment is operating normally."
        return headline, table, {"kind": "pie", "x": "Condition", "y": "Units", "title": "Equipment condition"}

    if question_id == "critical_alerts":
        selected = alerts[alerts["level"] == "CRITICAL"]
        table = count_table(selected["category"], "Category").rename(columns={"Count": "Critical alerts"})
        headline = str(len(selected)) + " critical alerts are currently active."
        return headline, table, {"kind": "bar", "x": "Category", "y": "Critical alerts", "title": "Critical alerts by category"}

    if question_id == "areas":
        rows = []
        for department in DEPARTMENTS:
            number_incidents = len(incidents[incidents["department"] == department])
            number_risks = len(risks[(risks["department"] == department) & (risks["risk_score"] >= 10) & (risks["status"] != "Closed")])
            number_workers = len(workers[(workers["department"] == department) & (workers["risk_level"].isin(["High", "Critical"]))])
            number_equipment = len(equipment[(equipment["department"] == department) & (equipment["condition"] == "Critical")])
            rows.append({"Department": department, "Incidents": number_incidents, "High/Critical risks": number_risks,
                         "High-risk workers": number_workers, "Critical equipment": number_equipment,
                         "Attention score": number_incidents + number_risks + number_workers + number_equipment})
        table = pd.DataFrame(rows).sort_values("Attention score", ascending=False)
        headline = table.iloc[0]["Department"] + " requires the greatest attention (score " + str(table.iloc[0]["Attention score"]) + ")."
        return headline, table, {"kind": "bar", "x": "Department", "y": "Attention score", "title": "Attention score by department"}

    if question_id == "recommendations":
        advice = recommendations(data, days)
        headline = str(len(advice)) + " recommendations were generated from the current data."
        return headline, pd.DataFrame({"Recommendation": advice}), None

    return "Question not found.", None, None
