# Khwezi Mining Health And Safety (simple version)

## Run
    pip install -r requirements.txt
    python -m streamlit run app.py

Sample data and the demo users are created in the `data` folder the first time the app runs.

## Demo accounts
| Username    | Password     | Role                 |
|-------------|--------------|----------------------|
| admin       | Admin@2026   | Administrator        |
| safety      | Safety@2026  | Safety Officer       |
| mining      | Mining@2026  | Mining Engineer      |
| maintenance | Maint@2026   | Maintenance Engineer |
| manager     | Manager@2026 | Manager              |

## Files
- settings.py     lists, thresholds, roles and permissions (change limits here)
- sample_data.py  creates the made-up data on first run
- core.py         loading/saving data, users and login, engineering rules, alerts, KPIs, report
- analysis.py     the 30 analysis questions (Appendix A)
- app.py          the screens (login and every page)

Thresholds are educational prototype values, not manufacturer or mine safety limits.
