# core.py
# The "brain" of the app: loading data, users and logins, the engineering rules,
# alerts, KPIs, the analysis questions and the report.
# This file does not use Streamlit, so every rule can be tested on its own.

import os
import pandas as pd
from settings import *
from sample_data import create_sample_data, create_default_users, hash_password, TODAY


# ===============================================================
# 1. LOADING AND SAVING DATA
# ===============================================================
def make_sure_data_exists():
    # Creates the sample data and demo users the first time the app runs
    if not os.path.exists(WORKERS_FILE) or not os.path.exists(INCIDENTS_FILE) \
            or not os.path.exists(EQUIPMENT_FILE) or not os.path.exists(RISKS_FILE):
        create_sample_data()
    if not os.path.exists(USERS_FILE):
        create_default_users()


def load_data():
    # Reads the four CSV files and returns them in a dictionary
    make_sure_data_exists()
    data = {}
    data["workers"] = pd.read_csv(WORKERS_FILE)
    data["incidents"] = pd.read_csv(INCIDENTS_FILE)
    data["equipment"] = pd.read_csv(EQUIPMENT_FILE)
    data["risks"] = pd.read_csv(RISKS_FILE)

    # change the date columns from text to dates
    data["incidents"]["date"] = pd.to_datetime(data["incidents"]["date"])
    data["risks"]["date"] = pd.to_datetime(data["risks"]["date"])
    data["equipment"]["last_service"] = pd.to_datetime(data["equipment"]["last_service"])
    data["equipment"]["next_service_due"] = pd.to_datetime(data["equipment"]["next_service_due"])
    return data


def save_table(name, df):
    # Saves one table back to its CSV file. name is workers, incidents, equipment or risks
    files = {"workers": WORKERS_FILE, "incidents": INCIDENTS_FILE,
             "equipment": EQUIPMENT_FILE, "risks": RISKS_FILE}
    df = df.copy()
    for column in df.columns:
        if pd.api.types.is_datetime64_any_dtype(df[column]):
            df[column] = df[column].dt.strftime("%Y-%m-%d")
    df.to_csv(files[name], index=False)


def reset_sample_data():
    create_sample_data()


def next_id(ids, prefix, width=3):
    # Works out the next ID, e.g. WK-064 -> WK-065
    biggest = 0
    for one_id in ids:
        number = int(str(one_id).split("-")[-1])
        if number > biggest:
            biggest = number
    return prefix + str(biggest + 1).zfill(width)


def filter_period(df, days):
    # Keeps only the rows from the last <days> days (None = keep everything)
    if days is None:
        return df
    start = TODAY - pd.Timedelta(days=days)
    return df[df["date"] >= start]


# ===============================================================
# 2. USERS, LOGIN AND ACCESS CONTROL
# ===============================================================
def load_users():
    make_sure_data_exists()
    return pd.read_csv(USERS_FILE)


def login(username, password):
    # Returns the user's details if the login is correct, otherwise None
    users = load_users()
    username = username.strip().lower()
    for index, row in users.iterrows():
        if row["username"] == username and row["password"] == hash_password(password):
            return {"username": username, "name": row["name"], "role": row["role"]}
    return None


def check_new_user(username, name, password):
    # Returns a list of error messages (empty list = everything is fine)
    errors = []
    users = load_users()
    if len(username) < 3 or len(username) > 20 or not username.replace("_", "").isalnum() or username != username.lower():
        errors.append("Username must be 3-20 characters: lowercase letters, numbers or underscores.")
    elif username in list(users["username"]):
        errors.append("That username already exists.")
    if name.strip() == "":
        errors.append("Full name is required.")
    if len(password) < 8:
        errors.append("Password must be at least 8 characters.")
    return errors


def add_user(username, name, role, password):
    users = load_users()
    new_row = pd.DataFrame([{"username": username, "name": name.strip(), "role": role,
                             "password": hash_password(password)}])
    users = pd.concat([users, new_row], ignore_index=True)
    users.to_csv(USERS_FILE, index=False)


def change_role(username, role):
    users = load_users()
    users.loc[users["username"] == username, "role"] = role
    users.to_csv(USERS_FILE, index=False)


def change_password(username, password):
    users = load_users()
    users.loc[users["username"] == username, "password"] = hash_password(password)
    users.to_csv(USERS_FILE, index=False)


def delete_user(username):
    users = load_users()
    users = users[users["username"] != username]
    users.to_csv(USERS_FILE, index=False)


def can(role, function):
    # True if this role may use this function (Table 1 of the brief)
    return function in PERMISSIONS[role]


def can_edit(role, function):
    # True if this role may add or change records
    if function in EDIT_ROLES:
        return role in EDIT_ROLES[function]
    return False


def permission_table():
    # Builds Table 1 so it can be shown on the user management page
    rows = []
    for function in FUNCTIONS:
        row = {"Function": function}
        for role in ROLES:
            if can(role, function):
                row[role] = "✓"
            else:
                row[role] = "-"
        rows.append(row)
    return pd.DataFrame(rows)


# ===============================================================
# 3. ENGINEERING RULES
# ===============================================================
def risk_score(likelihood, consequence):
    return int(likelihood) * int(consequence)


def classify_risk(score):
    # 1-4 Low, 5-9 Medium, 10-16 High, 17-25 Critical
    if score <= 4:
        return "Low"
    elif score <= 9:
        return "Medium"
    elif score <= 16:
        return "High"
    else:
        return "Critical"


def risk_warning(classification):
    if classification == "Critical":
        return "CRITICAL RISK: stop the activity and escalate to management immediately."
    elif classification == "High":
        return "HIGH RISK: apply additional controls and review before work continues."
    else:
        return None


def parameter_status(value, warn, crit):
    # Normal below warn, Warning from warn to crit, Critical above crit
    if value > crit:
        return "Critical"
    elif value >= warn:
        return "Warning"
    else:
        return "Normal"


def condition_message(temperature, vibration):
    # Returns the condition ("Normal", "Warning" or "Critical") and the message to show
    temp_status = parameter_status(temperature, TEMP_WARN, TEMP_CRIT)
    vib_status = parameter_status(vibration, VIB_WARN, VIB_CRIT)

    if temp_status == "Critical" or vib_status == "Critical":
        if vib_status == "Critical":
            what = "vibration"
        else:
            what = "temperature"
        return "Critical", "CRITICAL: Equipment " + what + " exceeds predefined threshold. Inspection required."
    elif temp_status == "Warning" or vib_status == "Warning":
        if temp_status == "Warning":
            what = "temperature"
        else:
            what = "vibration"
        return "Warning", "WARNING: Equipment " + what + " approaching predefined threshold."
    else:
        return "Normal", "NORMAL: Equipment operating within defined monitoring limits."


def availability(operating_time, downtime):
    # Availability = operating time / (operating time + downtime) x 100
    total = operating_time + downtime
    if total == 0:
        return 0.0
    return round(operating_time / total * 100, 1)


def add_risk_columns(risks):
    # Adds the risk score and classification to the risk register
    risks = risks.copy()
    risks["risk_score"] = risks["likelihood"] * risks["consequence"]
    risks["classification"] = risks["risk_score"].apply(classify_risk)
    return risks


def add_equipment_columns(equipment):
    # Adds availability, condition, service state and maintenance priority to each unit
    equipment = equipment.copy()
    availability_list = []
    condition_list = []
    message_list = []
    days_list = []
    state_list = []
    excessive_list = []
    low_list = []
    repeated_list = []
    score_list = []
    priority_list = []
    needs_list = []

    for index, unit in equipment.iterrows():
        avail = availability(unit["operating_time_h"], unit["downtime_h"])
        condition, message = condition_message(unit["temperature_c"], unit["vibration_mm_s"])
        days_to_service = (unit["next_service_due"] - TODAY).days

        # service state
        if unit["maintenance_status"] == "Under maintenance":
            state = "Under maintenance"
        elif days_to_service < 0:
            state = "Overdue"
        elif days_to_service <= SERVICE_DUE_DAYS:
            state = "Due soon"
        else:
            state = "Up to date"

        excessive = unit["downtime_h"] >= EXCESSIVE_DOWNTIME_H
        low = avail < LOW_AVAILABILITY
        repeated = unit["alerts_30d"] >= REPEATED_ALERTS

        # maintenance priority score (units already in the workshop score 0)
        score = 0
        if state != "Under maintenance":
            if condition == "Critical":
                score = score + 3
            elif condition == "Warning":
                score = score + 1
            if state == "Overdue":
                score = score + 3
            elif state == "Due soon":
                score = score + 1
            if low:
                score = score + 2
            if excessive:
                score = score + 1
            if repeated:
                score = score + 2
            if unit["engine_status"] == "Major fault":
                score = score + 2

        if score >= 6:
            priority = "Immediate"
        elif score >= 3:
            priority = "High"
        elif score >= 1:
            priority = "Medium"
        else:
            priority = "Routine"

        needs = False
        if state != "Under maintenance":
            if state == "Overdue" or state == "Due soon" or condition == "Critical" or low or repeated:
                needs = True

        availability_list.append(avail)
        condition_list.append(condition)
        message_list.append(message)
        days_list.append(days_to_service)
        state_list.append(state)
        excessive_list.append(excessive)
        low_list.append(low)
        repeated_list.append(repeated)
        score_list.append(score)
        priority_list.append(priority)
        needs_list.append(needs)

    equipment["availability_pct"] = availability_list
    equipment["condition"] = condition_list
    equipment["condition_message"] = message_list
    equipment["days_to_service"] = days_list
    equipment["service_state"] = state_list
    equipment["excessive_downtime"] = excessive_list
    equipment["low_availability"] = low_list
    equipment["repeated_alerts"] = repeated_list
    equipment["priority_score"] = score_list
    equipment["priority"] = priority_list
    equipment["needs_maintenance"] = needs_list
    return equipment


def add_worker_columns(workers):
    # Gives each worker risk points, a risk level and a text with the warnings
    workers = workers.copy()
    points_list = []
    warning_list = []

    for index, worker in workers.iterrows():
        points = 0
        messages = []

        if worker["ppe_compliance_pct"] < PPE_CRIT:
            points = points + 3
            messages.append("PPE compliance critically low")
        elif worker["ppe_compliance_pct"] < PPE_WARN:
            points = points + 2
            messages.append("PPE compliance low")

        if worker["fatigue_level"] >= FATIGUE_EXTREME:
            points = points + 3
            messages.append("Extreme fatigue")
        elif worker["fatigue_level"] >= FATIGUE_HIGH:
            points = points + 2
            messages.append("High fatigue")

        if worker["training_status"] == "Expired":
            points = points + 2
            messages.append("Safety training expired")
        elif worker["training_status"] == "Expiring soon":
            points = points + 1
            messages.append("Safety training expiring")

        if worker["previous_incidents"] >= 3:
            points = points + 2
            messages.append("Repeat incident history")
        elif worker["previous_incidents"] == 2:
            points = points + 1
            messages.append("Two previous incidents")

        if worker["near_misses"] >= 3:
            points = points + 1
            messages.append("Frequent near misses")

        points_list.append(points)
        warning_list.append("; ".join(messages))

    workers["risk_points"] = points_list
    workers["warnings"] = warning_list

    levels = []
    for points in points_list:
        if points >= 6:
            levels.append("Critical")
        elif points >= 4:
            levels.append("High")
        elif points >= 2:
            levels.append("Medium")
        else:
            levels.append("Low")
    workers["risk_level"] = levels
    return workers


# ===============================================================
# 4. ALERTS (Figure 1 of the brief)
# ===============================================================
def build_alerts(data):
    # Checks all the data against the thresholds and returns a table of alerts
    equipment = add_equipment_columns(data["equipment"])
    workers = add_worker_columns(data["workers"])
    incidents = data["incidents"]
    risks = add_risk_columns(data["risks"])
    alerts = []

    def add(level, category, label, subject, parameter, value, status, action, permission):
        alerts.append({"level": level, "category": category, "subject_label": label,
                       "subject": subject, "parameter": parameter, "value": value,
                       "status": status, "action": action, "permission": permission})

    # ---- equipment alerts ----
    inspect = "Inspect equipment and initiate appropriate maintenance/safety procedures."
    for index, unit in equipment.iterrows():
        if unit["maintenance_status"] == "Under maintenance":
            continue
        unit_id = unit["equipment_id"]

        temp_status = parameter_status(unit["temperature_c"], TEMP_WARN, TEMP_CRIT)
        if temp_status == "Critical":
            add("CRITICAL", "Equipment", "Equipment ID", unit_id, "Temperature",
                str(unit["temperature_c"]) + " °C", "Above Critical Threshold", inspect, "Equipment data")
        elif temp_status == "Warning":
            add("WARNING", "Equipment", "Equipment ID", unit_id, "Temperature",
                str(unit["temperature_c"]) + " °C", "In Warning Range",
                "Schedule an inspection and monitor the trend.", "Equipment data")

        vib_status = parameter_status(unit["vibration_mm_s"], VIB_WARN, VIB_CRIT)
        if vib_status == "Critical":
            add("CRITICAL", "Equipment", "Equipment ID", unit_id, "Vibration",
                str(unit["vibration_mm_s"]) + " mm/s", "Above Critical Threshold", inspect, "Equipment data")
        elif vib_status == "Warning":
            add("WARNING", "Equipment", "Equipment ID", unit_id, "Vibration",
                str(unit["vibration_mm_s"]) + " mm/s", "In Warning Range",
                "Schedule an inspection and monitor the trend.", "Equipment data")

        if unit["excessive_downtime"]:
            add("WARNING", "Maintenance", "Equipment ID", unit_id, "Downtime",
                str(round(unit["downtime_h"])) + " h", "Excessive Downtime",
                "Review failure causes and plan corrective maintenance.", "Maintenance data")
        if unit["low_availability"]:
            add("WARNING", "Maintenance", "Equipment ID", unit_id, "Availability",
                str(unit["availability_pct"]) + "%", "Below " + str(round(LOW_AVAILABILITY)) + "% target",
                "Investigate downtime and review the maintenance plan.", "Maintenance data")
        if unit["service_state"] == "Overdue":
            if unit["days_to_service"] < -30:
                level = "CRITICAL"
            else:
                level = "WARNING"
            add(level, "Maintenance", "Equipment ID", unit_id, "Service due date",
                str(abs(unit["days_to_service"])) + " days overdue", "Overdue Maintenance",
                "Book the unit into the workshop for service.", "Maintenance data")
        if unit["repeated_alerts"]:
            add("WARNING", "Maintenance", "Equipment ID", unit_id, "Alerts (30 days)",
                str(unit["alerts_30d"]) + " alerts", "Repeated Alerts",
                "Carry out a root-cause inspection.", "Maintenance data")

    # ---- worker alerts ----
    for index, worker in workers.iterrows():
        if worker["ppe_compliance_pct"] < PPE_WARN:
            if worker["ppe_compliance_pct"] < PPE_CRIT:
                level = "CRITICAL"
            else:
                level = "WARNING"
            add(level, "Worker safety", "Worker ID", worker["worker_id"], "PPE compliance",
                str(worker["ppe_compliance_pct"]) + "%", "Low PPE Compliance",
                "Conduct a PPE check and coaching before next shift.", "Worker safety data")
        if worker["fatigue_level"] >= FATIGUE_HIGH:
            if worker["fatigue_level"] >= FATIGUE_EXTREME:
                level = "CRITICAL"
            else:
                level = "WARNING"
            add(level, "Worker safety", "Worker ID", worker["worker_id"], "Fatigue level",
                str(worker["fatigue_level"]) + "/10", "High Fatigue Level",
                "Assess fitness for duty and consider reassignment or rest.", "Worker safety data")

    # ---- critical incidents that are not closed ----
    for index, incident in incidents.iterrows():
        if incident["severity"] == "Critical" and incident["status"] != "Closed":
            add("CRITICAL", "Incident", "Incident ID", incident["incident_id"], "Severity",
                incident["severity"], incident["status"] + " - " + incident["incident_type"],
                "Complete the investigation and implement corrective action.", "Safety incidents")

    # ---- high and critical risks that are not closed ----
    for index, risk in risks.iterrows():
        if risk["status"] != "Closed" and risk["risk_score"] >= 10:
            if risk["classification"] == "Critical":
                level = "CRITICAL"
            else:
                level = "WARNING"
            add(level, "Risk", "Risk ID", risk["risk_id"], "Risk score",
                str(risk["risk_score"]) + " (" + risk["classification"] + ")", risk["hazard"],
                risk_warning(risk["classification"]), "Risk assessment")

    columns = ["level", "category", "subject_label", "subject", "parameter", "value",
               "status", "action", "permission"]
    alerts = pd.DataFrame(alerts, columns=columns)
    if len(alerts) == 0:
        alerts.insert(0, "alert_id", [])
        return alerts

    # critical alerts first
    alerts["order"] = alerts["level"].map({"CRITICAL": 0, "WARNING": 1})
    alerts = alerts.sort_values(["order", "category", "subject"]).drop(columns="order")
    alerts = alerts.reset_index(drop=True)
    alerts.insert(0, "alert_id", ["ALT-" + str(n).zfill(3) for n in range(1, len(alerts) + 1)])
    return alerts


def format_alert(alert):
    # Turns one alert into the text layout shown in Figure 1 of the brief
    text = "MINING MONITORING ALERT\n"
    text = text + "[" + alert["level"] + "]\n"
    text = text + alert["subject_label"] + ": " + alert["subject"] + "\n"
    text = text + "Parameter: " + alert["parameter"] + "\n"
    text = text + "Value: " + alert["value"] + "\n"
    text = text + "Status: " + alert["status"] + "\n"
    text = text + "Recommended Action:\n"
    text = text + "  " + alert["action"]
    return text


def alerts_for_role(alerts, role):
    # Keeps only the alerts this role is allowed to see
    keep = []
    for permission in alerts["permission"]:
        keep.append(can(role, permission))
    return alerts[keep].reset_index(drop=True)


# ===============================================================
# 5. KPIs FOR THE DASHBOARD
# ===============================================================
def safety_kpis(data, days):
    workers = add_worker_columns(data["workers"])
    incidents = filter_period(data["incidents"], days)
    risks = add_risk_columns(data["risks"])

    kpis = {}
    kpis["total_workers"] = len(workers)
    kpis["total_incidents"] = len(incidents)
    kpis["near_misses"] = int(workers["near_misses"].sum())
    kpis["high_risk_obs"] = len(risks[(risks["risk_score"] >= 10) & (risks["status"] != "Closed")])
    kpis["ppe_compliance"] = round(workers["ppe_compliance_pct"].mean(), 1)
    kpis["critical_incidents"] = len(incidents[incidents["severity"] == "Critical"])
    kpis["lti"] = len(incidents[incidents["lost_time_injury"] == "Yes"])
    return kpis


def equipment_kpis(data):
    equipment = add_equipment_columns(data["equipment"])
    under_maintenance = len(equipment[equipment["maintenance_status"] == "Under maintenance"])
    normal = len(equipment[equipment["condition"] == "Normal"])

    kpis = {}
    kpis["total_equipment"] = len(equipment)
    kpis["available"] = len(equipment) - under_maintenance
    kpis["under_maintenance"] = under_maintenance
    kpis["equipment_alerts"] = len(equipment[equipment["condition"] != "Normal"])
    kpis["critical_equipment"] = len(equipment[equipment["condition"] == "Critical"])
    kpis["avg_availability"] = round(equipment["availability_pct"].mean(), 1)
    kpis["pct_normal"] = round(normal / len(equipment) * 100, 1)
    return kpis


# ===============================================================
# 6. RECOMMENDATIONS AND REPORT
# ===============================================================
def recommendations(data, days):
    workers = add_worker_columns(data["workers"])
    equipment = add_equipment_columns(data["equipment"])
    incidents = filter_period(data["incidents"], days)
    risks = add_risk_columns(data["risks"])
    advice = []

    # equipment that needs an inspection now
    for index, unit in equipment.iterrows():
        if unit["condition"] == "Critical" and unit["maintenance_status"] != "Under maintenance":
            reason = unit["condition_message"].split(": ")[1]
            advice.append("Inspect " + unit["equipment_id"] + " now: " + reason)

    overdue = len(equipment[equipment["service_state"] == "Overdue"])
    if overdue > 0:
        advice.append("Clear the backlog of " + str(overdue) + " overdue services, starting with the lowest-availability units.")

    low = equipment[equipment["low_availability"]]
    if len(low) > 0:
        names = ", ".join(list(low["equipment_id"].head(4)))
        if len(low) > 4:
            names = names + "..."
        advice.append("Review the maintenance plan for " + str(len(low)) + " units below "
                      + str(round(LOW_AVAILABILITY)) + "% availability (" + names + ").")

    average_ppe = workers["ppe_compliance_pct"].mean()
    if average_ppe < PPE_TARGET:
        advice.append("Run a PPE campaign: average compliance is " + str(round(average_ppe, 1))
                      + "% against a " + str(round(PPE_TARGET)) + "% target.")

    tired = len(workers[workers["fatigue_level"] >= FATIGUE_HIGH])
    if tired > 0:
        advice.append("Assess fitness for duty for " + str(tired) + " workers with high fatigue and review night-shift rosters.")

    expired = len(workers[workers["training_status"] == "Expired"])
    if expired > 0:
        advice.append("Re-train " + str(expired) + " workers whose safety training has expired.")

    if len(incidents) > 0:
        top_shift = incidents["shift"].value_counts().index[0]
        top_department = incidents["department"].value_counts().index[0]
        top_cause = incidents["cause"].value_counts().index[0]
        advice.append("Focus supervision on the " + top_shift + " shift and " + top_department
                      + ", and address the leading cause: " + top_cause.lower() + ".")

    open_risks = len(risks[(risks["risk_score"] >= 10) & (risks["status"] != "Closed")])
    if open_risks > 0:
        advice.append("Review controls for " + str(open_risks) + " open high or critical risks before the next planning meeting.")

    if len(advice) == 0:
        advice.append("No priority actions identified. Continue routine monitoring.")
    return advice


def build_report(data, user, days, period_label):
    # Builds the text report. Each role only gets the sections it is allowed to see.
    role = user["role"]
    sees_safety = can(role, "Safety incidents") or can(role, "Worker safety data")
    sees_equipment = can(role, "Equipment data")

    lines = []
    lines.append("KHWEZI MINING HEALTH AND SAFETY - MONITORING REPORT")
    lines.append("=" * 60)
    lines.append("Generated: " + pd.Timestamp.now().strftime("%Y-%m-%d %H:%M"))
    lines.append("Prepared for: " + user["name"] + " (" + role + ")")
    lines.append("Reporting period: " + period_label)
    lines.append("")

    if sees_safety:
        k = safety_kpis(data, days)
        lines.append("WORKER HEALTH AND SAFETY")
        lines.append("-" * 60)
        lines.append("Total workers: " + str(k["total_workers"]))
        lines.append("Average PPE compliance: " + str(k["ppe_compliance"]) + "%")
        lines.append("Near misses recorded: " + str(k["near_misses"]))
        lines.append("Incidents in period: " + str(k["total_incidents"]))
        lines.append("Critical incidents: " + str(k["critical_incidents"]))
        lines.append("Lost-time injuries: " + str(k["lti"]))
        lines.append("Open high/critical risks: " + str(k["high_risk_obs"]))
        lines.append("")

    if sees_equipment:
        k = equipment_kpis(data)
        lines.append("EQUIPMENT")
        lines.append("-" * 60)
        lines.append("Total equipment: " + str(k["total_equipment"]))
        lines.append("Available: " + str(k["available"]))
        lines.append("Under maintenance: " + str(k["under_maintenance"]))
        lines.append("Units with condition alerts: " + str(k["equipment_alerts"]))
        lines.append("Critical units: " + str(k["critical_equipment"]))
        lines.append("Average availability: " + str(k["avg_availability"]) + "%")
        lines.append("Operating normally: " + str(k["pct_normal"]) + "%")
        lines.append("")

    alerts = alerts_for_role(build_alerts(data), role)
    critical = alerts[alerts["level"] == "CRITICAL"]
    warnings = alerts[alerts["level"] == "WARNING"]
    lines.append("ACTIVE ALERTS")
    lines.append("-" * 60)
    lines.append("Critical: " + str(len(critical)) + "   Warning: " + str(len(warnings)))
    lines.append("")
    for index, alert in critical.head(10).iterrows():
        lines.append(format_alert(alert))
        lines.append("")

    # recommendations: keep the ones that fit the role
    lines.append("RECOMMENDATIONS")
    lines.append("-" * 60)
    equipment_words = ["Inspect", "service", "availability"]
    chosen = []
    for advice in recommendations(data, days):
        about_equipment = False
        for word in equipment_words:
            if word in advice:
                about_equipment = True
        if about_equipment and sees_equipment:
            chosen.append(advice)
        elif not about_equipment and sees_safety:
            chosen.append(advice)
    if len(chosen) == 0:
        chosen.append("No actions for your role.")
    number = 1
    for advice in chosen:
        lines.append(str(number) + ". " + advice)
        number = number + 1

    lines.append("")
    lines.append("Note: thresholds are educational prototype values, not manufacturer or mine safety limits.")
    return "\n".join(lines)
