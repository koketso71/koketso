# sample_data.py
# Creates the made-up (synthetic) data used by the app the first time it runs.
# The dates are created relative to today, so the data always looks current.

import os
import random
import hashlib
import pandas as pd
from settings import *

random.seed(2026)
TODAY = pd.Timestamp.today().normalize()


def keep_between(value, low, high):
    # Keeps a number inside a range
    if value < low:
        return low
    if value > high:
        return high
    return value


def make_workers():
    rows = []
    for i in range(1, 65):
        department = random.choices(DEPARTMENTS, weights=[22, 24, 10, 16, 18, 10])[0]
        worker = {
            "worker_id": "WK-" + str(i).zfill(3),
            "department": department,
            "job_role": random.choice(JOB_ROLES[department]),
            "shift": random.choices(SHIFTS, weights=[45, 30, 25])[0],
            "ppe_compliance_pct": round(keep_between(random.gauss(90, 9), 50, 100)),
            "training_status": random.choices(TRAINING_STATUS, weights=[78, 14, 8])[0],
            "fatigue_level": round(keep_between(random.gauss(4.3, 2.2), 1, 10)),
            "safety_observations": random.choice([0, 1, 2, 2, 3, 4]),
            "near_misses": random.choice([0, 0, 0, 1, 1, 2, 3]),
            "previous_incidents": random.choices([0, 1, 2, 3], weights=[62, 24, 10, 4])[0],
        }
        rows.append(worker)
    return pd.DataFrame(rows)


def make_incidents():
    rows = []
    for i in range(140):
        shift = random.choices(SHIFTS, weights=[38, 27, 35])[0]

        # choose an hour that matches the shift
        if shift == "Day":
            hour = random.randint(6, 13)
        elif shift == "Afternoon":
            hour = random.randint(14, 21)
        else:
            hour = random.choice([22, 23, 0, 1, 2, 3, 4, 5])
        time = str(hour).zfill(2) + ":" + str(random.randint(0, 59)).zfill(2)

        days_ago = random.randint(0, 364)
        date = TODAY - pd.Timedelta(days=days_ago)
        department = random.choices(DEPARTMENTS, weights=[26, 24, 12, 14, 16, 8])[0]
        severity = random.choices(SEVERITIES, weights=[45, 30, 17, 8])[0]

        # injury depends on the severity
        if severity == "Low":
            injury = random.choices(["No injury", "First aid"], weights=[60, 40])[0]
        elif severity == "Medium":
            injury = random.choices(["First aid", "Medical treatment"], weights=[65, 35])[0]
        elif severity == "High":
            injury = random.choices(["Medical treatment", "Serious injury"], weights=[70, 30])[0]
        else:
            injury = random.choices(["Serious injury", "Medical treatment"], weights=[80, 20])[0]

        # lost-time injury
        lost_time = "No"
        if injury == "Serious injury" and random.random() < 0.9:
            lost_time = "Yes"
        if injury == "Medical treatment" and random.random() < 0.3:
            lost_time = "Yes"

        cause = random.choices(INCIDENT_CAUSES, weights=[20, 12, 16, 10, 10, 10, 10, 12])[0]

        # recent incidents are more likely to still be open
        if days_ago < 45:
            status = random.choices(INCIDENT_STATUS, weights=[30, 35, 35])[0]
        else:
            status = random.choices(INCIDENT_STATUS, weights=[2, 6, 92])[0]

        rows.append({
            "date": date.strftime("%Y-%m-%d"),
            "time": time,
            "shift": shift,
            "location": random.choice(LOCATIONS_BY_DEPARTMENT[department]),
            "department": department,
            "incident_type": random.choice(INCIDENT_TYPES),
            "severity": severity,
            "injury_status": injury,
            "lost_time_injury": lost_time,
            "cause": cause,
            "corrective_action": CORRECTIVE_ACTIONS[cause],
            "status": status,
        })

    df = pd.DataFrame(rows)
    df = df.sort_values(["date", "time"]).reset_index(drop=True)
    df.insert(0, "incident_id", ["INC-" + str(TODAY.year) + "-" + str(n).zfill(4) for n in range(1, len(df) + 1)])

    # make sure the newest critical incident is still being investigated
    critical = df[df["severity"] == "Critical"]
    if len(critical) > 0:
        df.loc[critical.index[-1], "status"] = "Under investigation"
    return df


def make_equipment():
    rows = []
    for equipment_type in EQUIPMENT_TYPES:
        prefix, count, makers, fuel, has_tyres, has_brakes, department = EQUIPMENT_TYPES[equipment_type]
        for n in range(1, count + 1):
            last_service = TODAY - pd.Timedelta(days=random.randint(5, 150))
            interval = random.choice([60, 90, 120])
            temperature = keep_between(random.gauss(72, 13), 45, 118)
            vibration = keep_between(random.gauss(3.7, 1.9), 0.8, 10.5)
            downtime = keep_between(random.expovariate(1 / 105), 12, 430)

            # equipment that runs hot or vibrates has more alerts
            alerts = random.choice([0, 0, 1, 1, 2])
            if vibration >= VIB_WARN:
                alerts = alerts + 2
            if temperature >= TEMP_WARN:
                alerts = alerts + 2

            if has_brakes:
                brake = random.choices(["Good", "Worn", "Replace"], weights=[80, 15, 5])[0]
            else:
                brake = "N/A"
            if has_tyres:
                tyre = random.choices(["Good", "Worn", "Replace"], weights=[78, 17, 5])[0]
            else:
                tyre = "N/A"

            rows.append({
                "equipment_id": prefix + "-" + str(n).zfill(3),
                "equipment_type": equipment_type,
                "manufacturer": random.choice(makers),
                "department": department,
                "location": random.choice(EQUIPMENT_LOCATIONS),
                "operating_hours": random.randint(3000, 38000),
                "temperature_c": round(temperature, 1),
                "vibration_mm_s": round(vibration, 1),
                "fuel_l_per_h": round(fuel * random.uniform(0.85, 1.15), 1),
                "brake_status": brake,
                "tyre_status": tyre,
                "engine_status": random.choices(["Running normally", "Minor fault", "Major fault"], weights=[82, 14, 4])[0],
                "maintenance_status": "In service",
                "operating_time_h": random.randint(1500, 1950),
                "downtime_h": round(downtime, 1),
                "last_service": last_service.strftime("%Y-%m-%d"),
                "service_interval_days": interval,
                "next_service_due": (last_service + pd.Timedelta(days=interval)).strftime("%Y-%m-%d"),
                "alerts_30d": alerts,
            })
    df = pd.DataFrame(rows)

    # the worked example from the project brief: TRK-012 vibrating at 9.2 mm/s
    row = df.index[df["equipment_id"] == "TRK-012"][0]
    df.loc[row, "vibration_mm_s"] = 9.2
    df.loc[row, "temperature_c"] = 91.0
    df.loc[row, "alerts_30d"] = 4

    # three units are in the workshop
    for unit in ["EXC-002", "LDR-004", "CNV-003"]:
        df.loc[df["equipment_id"] == unit, "maintenance_status"] = "Under maintenance"
    return df


def make_risks():
    rows = []
    hazards = HAZARDS[:]
    random.shuffle(hazards)
    for i in range(1, 33):
        department = random.choice(DEPARTMENTS)
        rows.append({
            "risk_id": "RSK-" + str(i).zfill(3),
            "date": (TODAY - pd.Timedelta(days=random.randint(0, 149))).strftime("%Y-%m-%d"),
            "hazard": hazards[i % len(hazards)],
            "department": department,
            "location": random.choice(LOCATIONS_BY_DEPARTMENT[department]),
            "likelihood": random.choices([1, 2, 3, 4, 5], weights=[12, 25, 28, 22, 13])[0],
            "consequence": random.choices([1, 2, 3, 4, 5], weights=[10, 20, 28, 27, 15])[0],
            "control_measure": random.choice(["Engineering control", "Administrative control", "PPE",
                                              "Supervision", "Isolation and lock-out", "Redesign of task"]),
            "owner": random.choice(["Safety Officer", "Mining Engineer", "Shift Supervisor"]),
            "status": random.choices(RISK_STATUS, weights=[55, 30, 15])[0],
        })
    return pd.DataFrame(rows)


def hash_password(password):
    # Passwords are stored as a hash, not as plain text
    return hashlib.sha256(password.encode()).hexdigest()


def make_users():
    rows = []
    for username, name, role, password in DEFAULT_USERS:
        rows.append({"username": username, "name": name, "role": role, "password": hash_password(password)})
    return pd.DataFrame(rows)


def create_sample_data():
    # Creates the data folder and writes the four data files
    os.makedirs(DATA_FOLDER, exist_ok=True)
    make_workers().to_csv(WORKERS_FILE, index=False)
    make_incidents().to_csv(INCIDENTS_FILE, index=False)
    make_equipment().to_csv(EQUIPMENT_FILE, index=False)
    make_risks().to_csv(RISKS_FILE, index=False)


def create_default_users():
    os.makedirs(DATA_FOLDER, exist_ok=True)
    make_users().to_csv(USERS_FILE, index=False)
