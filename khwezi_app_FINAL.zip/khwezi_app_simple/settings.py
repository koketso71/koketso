# settings.py
# All the fixed values used by the app are kept here (lists, thresholds, roles).
# If you want to change a limit, change it in this file.

# NOTE: all thresholds are educational prototype values only.
# They are NOT manufacturer limits or real mine safety limits.

# ---------------------------------------------------------------
# Files
# ---------------------------------------------------------------
DATA_FOLDER = "data"
WORKERS_FILE = "data/workers.csv"
INCIDENTS_FILE = "data/incidents.csv"
EQUIPMENT_FILE = "data/equipment.csv"
RISKS_FILE = "data/risks.csv"
USERS_FILE = "data/users.csv"

# ---------------------------------------------------------------
# Lists used in drop-down menus
# ---------------------------------------------------------------
SHIFTS = ["Day", "Afternoon", "Night"]

DEPARTMENTS = [
    "Underground Production",
    "Surface Mining",
    "Drilling & Blasting",
    "Processing Plant",
    "Engineering & Maintenance",
    "Ventilation & Services",
]

SEVERITIES = ["Low", "Medium", "High", "Critical"]
INJURY_STATUS = ["No injury", "First aid", "Medical treatment", "Serious injury"]
INCIDENT_STATUS = ["Open", "Under investigation", "Closed"]
TRAINING_STATUS = ["Valid", "Expiring soon", "Expired"]
RISK_STATUS = ["Open", "Controlled", "Closed"]

INCIDENT_TYPES = [
    "Fall of ground", "Slip, trip or fall", "Vehicle collision", "Equipment failure",
    "Machinery entanglement", "Electrical", "Fire or heat", "Chemical exposure",
    "Struck by object", "Dust or noise exposure",
]

INCIDENT_CAUSES = [
    "Human error", "Inadequate PPE", "Equipment failure", "Poor housekeeping",
    "Fatigue", "Inadequate supervision", "Environmental conditions",
    "Procedure not followed",
]

# Standard corrective action for each cause
CORRECTIVE_ACTIONS = {
    "Human error": "Refresher training and task observation",
    "Inadequate PPE": "PPE issue check and compliance audit",
    "Equipment failure": "Inspect equipment and repair before return to service",
    "Poor housekeeping": "Area clean-up and housekeeping inspection schedule",
    "Fatigue": "Review shift length and fatigue management plan",
    "Inadequate supervision": "Increase supervisor presence on the shift",
    "Environmental conditions": "Reassess hazards and update the risk assessment",
    "Procedure not followed": "Toolbox talk and procedure re-issue",
}

JOB_ROLES = {
    "Underground Production": ["Miner", "Team Leader", "Rock Drill Operator", "Loco Operator"],
    "Surface Mining": ["Haul Truck Operator", "Loader Operator", "Shift Supervisor", "Dozer Operator"],
    "Drilling & Blasting": ["Driller", "Blaster", "Charge-up Assistant"],
    "Processing Plant": ["Plant Operator", "Crusher Operator", "Process Controller"],
    "Engineering & Maintenance": ["Fitter", "Electrician", "Boilermaker", "Artisan Assistant"],
    "Ventilation & Services": ["Ventilation Officer", "Environmental Technician", "Service Operator"],
}

LOCATIONS_BY_DEPARTMENT = {
    "Underground Production": ["Shaft 2 - 14 Level", "Shaft 2 - 22 Level", "Stope 14-3", "Haulage 22"],
    "Surface Mining": ["North Pit", "South Pit", "Pit Ramp 3", "Waste Dump"],
    "Drilling & Blasting": ["North Pit Bench 4", "South Pit Bench 2", "Shaft 2 - 14 Level"],
    "Processing Plant": ["Primary Crusher Station", "Plant Feed Section", "Stockpile Yard"],
    "Engineering & Maintenance": ["Workshop Bay", "Plant Feed Section", "Conveyor Gallery"],
    "Ventilation & Services": ["Shaft 2 - 22 Level", "Surface Fan Station", "Workshop Bay"],
}

EQUIPMENT_LOCATIONS = [
    "North Pit", "South Pit", "Shaft 2 - 14 Level", "Shaft 2 - 22 Level",
    "Primary Crusher Station", "Plant Feed Section", "Stockpile Yard", "Workshop Bay",
]

# For each equipment type:
# (ID prefix, how many units, manufacturers, fuel L/h, has tyres, has brakes, department)
EQUIPMENT_TYPES = {
    "Haul truck": ("TRK", 14, ["Caterpillar", "Komatsu", "Liebherr"], 85, True, True, "Surface Mining"),
    "Loader": ("LDR", 5, ["Caterpillar", "Sandvik", "Epiroc"], 42, True, True, "Surface Mining"),
    "Excavator": ("EXC", 5, ["Komatsu", "Liebherr", "Hitachi"], 60, False, False, "Surface Mining"),
    "Drilling machine": ("DRL", 4, ["Epiroc", "Sandvik"], 28, False, False, "Drilling & Blasting"),
    "Bulldozer": ("DOZ", 3, ["Caterpillar", "Komatsu"], 48, False, True, "Surface Mining"),
    "Scraper winch": ("SCW", 3, ["Joy Global", "Sandvik"], 0, False, True, "Underground Production"),
    "Crusher": ("CRS", 2, ["Metso", "FLSmidth"], 0, False, False, "Processing Plant"),
    "Conveyor": ("CNV", 4, ["Continental", "FLSmidth"], 0, False, False, "Processing Plant"),
}

HAZARDS = [
    "Unsupported hanging wall in active stope", "Haul road edge protection damaged",
    "Blast exclusion zone not enforced", "Conveyor guarding removed during repair",
    "Poor visibility on ramp at night", "Diesel particulate build-up in return airway",
    "Isolation procedure bypassed on crusher", "Loose rocks above access way",
    "Fatigue on extended night shift rotation", "Wet, slippery walkway at plant feed",
    "Heat stress in deep working area", "Overloaded haul truck on steep ramp",
    "Dust exposure during loading", "Unlabelled chemical containers in workshop",
    "Mobile equipment and pedestrian interaction", "Electrical panel with open cover",
    "Noise above exposure limit at crusher", "Stockpile slope instability",
]

# ---------------------------------------------------------------
# Thresholds (educational prototype values)
# ---------------------------------------------------------------
TEMP_WARN = 80.0      # degrees C
TEMP_CRIT = 100.0
VIB_WARN = 5.0        # mm/s
VIB_CRIT = 8.0

LOW_AVAILABILITY = 85.0        # % availability below this is "low"
EXCESSIVE_DOWNTIME_H = 250.0   # hours of downtime in the period
REPEATED_ALERTS = 3            # alerts in the last 30 days
SERVICE_DUE_DAYS = 14          # a service is "due soon" within this many days

PPE_TARGET = 85.0              # % compliance target
PPE_WARN = 80.0
PPE_CRIT = 65.0

FATIGUE_HIGH = 7               # fatigue level out of 10
FATIGUE_EXTREME = 9

# Reporting periods shown in the sidebar (None means all records)
PERIOD_OPTIONS = {
    "Last 30 days": 30,
    "Last 90 days": 90,
    "Last 6 months": 182,
    "Last 12 months": 365,
    "All records": None,
}

# ---------------------------------------------------------------
# Roles and permissions (Table 1 of the project brief)
# ---------------------------------------------------------------
ROLES = ["Administrator", "Safety Officer", "Mining Engineer", "Maintenance Engineer", "Manager"]

FUNCTIONS = [
    "View dashboard", "Worker safety data", "Safety incidents", "Equipment data",
    "Maintenance data", "Risk assessment", "Generate reports", "Manage users",
]

PERMISSIONS = {
    "Administrator": FUNCTIONS,
    "Safety Officer": ["View dashboard", "Worker safety data", "Safety incidents",
                       "Risk assessment", "Generate reports"],
    "Mining Engineer": ["View dashboard", "Worker safety data", "Safety incidents",
                        "Equipment data", "Maintenance data", "Risk assessment",
                        "Generate reports"],
    "Maintenance Engineer": ["View dashboard", "Equipment data", "Maintenance data",
                             "Generate reports"],
    "Manager": ["View dashboard", "Worker safety data", "Safety incidents", "Equipment data",
                "Maintenance data", "Risk assessment", "Generate reports"],
}

# Which roles may ADD or CHANGE records (every role with access can view)
EDIT_ROLES = {
    "Worker safety data": ["Administrator", "Safety Officer"],
    "Safety incidents": ["Administrator", "Safety Officer"],
    "Equipment data": ["Administrator", "Maintenance Engineer"],
    "Maintenance data": ["Administrator", "Maintenance Engineer"],
    "Risk assessment": ["Administrator", "Safety Officer", "Mining Engineer"],
}

# Demo accounts: (username, full name, role, password)
DEFAULT_USERS = [
    ("admin", "Thandiwe Mokoena", "Administrator", "Admin@2026"),
    ("safety", "Sipho Dlamini", "Safety Officer", "Safety@2026"),
    ("mining", "Lerato Nkosi", "Mining Engineer", "Mining@2026"),
    ("maintenance", "Pieter van Wyk", "Maintenance Engineer", "Maint@2026"),
    ("manager", "Naledi Khumalo", "Manager", "Manager@2026"),
]
