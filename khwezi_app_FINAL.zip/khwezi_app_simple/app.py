# app.py
# The user interface of "Khwezi Mining Health And Safety".
# Run it with:  python -m streamlit run app.py
#
# How the file is organised:
#   1. Imports, colours and styling
#   2. Small helper functions (tiles, tables, charts)
#   3. The login page
#   4. One function for each page of the app
#   5. main(), which puts everything together

import datetime
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

import core
import analysis
from settings import *


st.set_page_config(page_title="Khwezi Mining Health And Safety", page_icon="⛏️", layout="wide")

# ===============================================================
# 1. COLOURS AND STYLING  ("control room" theme)
# ===============================================================
BG = "#0B0F14"        # page background
PANEL = "#121A22"     # cards and charts
RAISED = "#18222D"    # tiles
LINE = "#243241"      # borders and grid lines
INK = "#E6EDF3"       # main text
MUTED = "#8B98A5"     # secondary text
AMBER = "#F5A524"
TEAL = "#2DD4BF"
BLUE = "#5AA9FF"
VIOLET = "#A78BFA"
RED = "#F05252"
GREEN = "#3DDC84"

# colours used to show a level in a table
LEVEL_COLORS = {
    "Critical": RED, "CRITICAL": RED, "High": AMBER, "Immediate": RED,
    "Warning": AMBER, "WARNING": AMBER, "Medium": BLUE, "Overdue": RED,
    "Due soon": AMBER, "Under maintenance": VIOLET,
    "Normal": GREEN, "Low": GREEN, "Routine": GREEN, "Up to date": GREEN,
}
SEVERITY_COLORS = {"Low": GREEN, "Medium": BLUE, "High": AMBER, "Critical": RED}
CONDITION_COLORS = {"Normal": GREEN, "Warning": AMBER, "Critical": RED}
SEQUENCE = [AMBER, TEAL, BLUE, VIOLET, RED, GREEN, "#F472B6", "#94A3B8"]
TONE_COLORS = {"neutral": BLUE, "ok": GREEN, "warn": AMBER, "crit": RED, "accent": VIOLET}

CSS = """
<style>
@import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@500;700&family=Inter:wght@400;500;600;800&display=swap');
html, body, .stApp, [data-testid="stMarkdownContainer"], [data-testid="stWidgetLabel"] { font-family: 'Inter', system-ui, sans-serif; }
.block-container { padding-top: 1.6rem; max-width: 1360px; }
header[data-testid="stHeader"] { background: transparent; }
.stApp:before { content: ""; position: fixed; top: 0; left: 0; right: 0; height: 6px; z-index: 999990;
  background: repeating-linear-gradient(-45deg, #F5A524 0 14px, #0B0F14 14px 28px); }

/* ---------- page header ---------- */
.ph { display: flex; align-items: flex-end; justify-content: space-between; gap: 16px;
  border-bottom: 1px solid #243241; padding-bottom: 14px; margin-bottom: 18px; }
.ph .code { font-family: 'JetBrains Mono', monospace; color: #F5A524; font-size: .78rem; letter-spacing: .22em; }
.ph .title { font-family: 'JetBrains Mono', monospace; font-weight: 700; font-size: 1.9rem; color: #E6EDF3;
  text-transform: uppercase; letter-spacing: .04em; line-height: 1.15; }
.ph .sub { color: #8B98A5; font-size: .95rem; margin-top: 4px; }
.ph .clock { font-family: 'JetBrains Mono', monospace; font-size: .78rem; color: #2DD4BF; border: 1px solid #243241;
  border-radius: 999px; padding: 5px 12px; white-space: nowrap; }
.section-title { font-family: 'JetBrains Mono', monospace; font-weight: 700; font-size: .95rem; color: #E6EDF3;
  text-transform: uppercase; letter-spacing: .12em; margin: 1.4rem 0 .6rem; display: flex; align-items: center; gap: 10px; }
.section-title:before { content: ""; width: 10px; height: 10px; background: #F5A524; border-radius: 2px; }

/* ---------- KPI tiles ---------- */
.tile { background: #18222D; border: 1px solid #243241; border-radius: 12px; padding: 14px 16px 12px;
  min-height: 108px; margin-bottom: 10px; position: relative; overflow: hidden; }
.tile:before { content: ""; position: absolute; left: 0; top: 0; bottom: 0; width: 4px; background: var(--c); }
.tile:after { content: ""; position: absolute; right: -30px; top: -30px; width: 90px; height: 90px; border-radius: 50%;
  background: radial-gradient(circle, color-mix(in srgb, var(--c) 22%, transparent), transparent 70%); }
.tile-label { font-size: .7rem; color: #8B98A5; font-weight: 600; text-transform: uppercase; letter-spacing: .09em; }
.tile-value { font-family: 'JetBrains Mono', monospace; font-size: 1.9rem; font-weight: 700; line-height: 1.25; color: #E6EDF3; }
.tile-sub { font-size: .78rem; color: var(--c); }

/* ---------- banners, answers, alert cards ---------- */
.banner { padding: 11px 16px; border-radius: 10px; border: 1px solid; margin-bottom: 14px; font-weight: 600; }
.banner-crit { background: rgba(240,82,82,.10); border-color: #F05252; color: #FF8A8A; }
.banner-ok { background: rgba(61,220,132,.10); border-color: #3DDC84; color: #7CEBB0; }
.banner-warn { background: rgba(245,165,36,.10); border-color: #F5A524; color: #FFC766; }
.answer { background: #18222D; border: 1px solid #243241; border-left: 4px solid #F5A524; border-radius: 10px;
  padding: 14px 18px; font-size: 1.1rem; margin-bottom: 12px; color: #E6EDF3; }
.lamps { display: grid; grid-template-columns: 1fr 1fr 2fr; gap: 10px; margin-bottom: 8px; }
.lamp { background: #18222D; border: 1px solid #243241; border-radius: 12px; padding: 12px 16px; display: flex; align-items: center; gap: 12px; }
.lamp .dot { width: 14px; height: 14px; border-radius: 50%; background: var(--c); box-shadow: 0 0 12px var(--c); }
.lamp .n { font-family: 'JetBrains Mono', monospace; font-size: 1.6rem; font-weight: 700; color: #E6EDF3; }
.lamp .t { font-size: .72rem; color: #8B98A5; text-transform: uppercase; letter-spacing: .09em; }
.meter { height: 8px; border-radius: 99px; overflow: hidden; display: flex; background: #243241; margin: 6px 0 2px; }
.acard { display: flex; gap: 12px; background: #18222D; border: 1px solid #243241; border-radius: 12px;
  padding: 11px 14px; margin-bottom: 8px; }
.acard .bar { width: 4px; border-radius: 4px; background: var(--c); flex: none; }
.acard .h { font-weight: 700; color: #E6EDF3; font-size: .92rem; }
.acard .m { color: #8B98A5; font-size: .82rem; margin-top: 2px; }
.pill { display: inline-block; padding: 1px 9px; border-radius: 999px; font-size: .68rem; font-weight: 700;
  font-family: 'JetBrains Mono', monospace; color: var(--c); border: 1px solid var(--c);
  background: color-mix(in srgb, var(--c) 15%, transparent); margin-right: 6px; }

/* ---------- sidebar ---------- */
[data-testid="stSidebar"] { background: #121A22; border-right: 1px solid #243241; }
.brand { padding: 6px 0 14px; }
.brand-name { font-family: 'JetBrains Mono', monospace; font-size: 1.35rem; font-weight: 700; letter-spacing: .2em; color: #F5A524; }
.brand-sub { font-family: 'JetBrains Mono', monospace; font-size: .72rem; letter-spacing: .18em; color: #8B98A5; }
.usercard { border: 1px solid #243241; background: #18222D; border-radius: 10px; padding: 10px 12px; margin: 6px 0 16px; font-size: .86rem; color: #E6EDF3; }
.usercard .role { font-family: 'JetBrains Mono', monospace; font-size: .7rem; color: #2DD4BF; letter-spacing: .06em; }
[data-testid="stSidebar"] [role="radiogroup"] { gap: 2px; }
[data-testid="stSidebar"] [role="radiogroup"] label { width: 100%; padding: 8px 10px; border-radius: 8px;
  border-left: 3px solid transparent; font-family: 'JetBrains Mono', monospace; }
[data-testid="stSidebar"] [data-testid="stRadioOption"] > div > div:first-child:not([data-testid]) { display: none; }
[data-testid="stSidebar"] [data-testid="stRadioOption"] { display: flex; box-sizing: border-box; }
[data-testid="stSidebar"] [data-testid="stRadioOption"] p { font-family: 'JetBrains Mono', monospace; font-size: .86rem; color: #8B98A5; }
[data-testid="stSidebar"] [data-testid="stRadioOption"]:hover { background: #18222D; }
[data-testid="stSidebar"] [data-testid="stRadioOption"][data-selected="true"] { background: #18222D; border-left-color: #F5A524; }
[data-testid="stSidebar"] [data-testid="stRadioOption"][data-selected="true"] p { color: #F5A524; font-weight: 700; }

/* ---------- login ---------- */
.gate { text-align: center; margin: 5vh 0 18px; }
.gate .logo { font-size: 2.6rem; }
.gate .name { font-family: 'JetBrains Mono', monospace; font-weight: 700; font-size: 2.2rem; letter-spacing: .28em; color: #F5A524; }
.gate .sub { font-family: 'JetBrains Mono', monospace; color: #8B98A5; letter-spacing: .16em; font-size: .8rem; }
.gate-feat { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-top: 18px; }
.gate-feat div { background: #18222D; border: 1px solid #243241; border-radius: 10px; padding: 10px; font-size: .8rem; color: #8B98A5; text-align: left; }
.gate-feat b { display: block; color: #E6EDF3; font-size: .85rem; margin-bottom: 2px; }
[data-testid="stForm"] { background: #121A22; border: 1px solid #243241 !important; border-radius: 14px; }
</style>
"""
st.markdown(CSS, unsafe_allow_html=True)

# nicer column names for tables
COLUMN_NAMES = {
    "worker_id": "Worker ID", "incident_id": "Incident ID", "equipment_id": "Equipment ID",
    "risk_id": "Risk ID", "alert_id": "Alert ID", "ppe_compliance_pct": "PPE compliance (%)",
    "temperature_c": "Temperature (°C)", "vibration_mm_s": "Vibration (mm/s)", "fuel_l_per_h": "Fuel (L/h)",
    "availability_pct": "Availability (%)", "downtime_h": "Downtime (h)", "operating_time_h": "Operating time (h)",
    "operating_hours": "Operating hours", "alerts_30d": "Alerts (30 days)", "lost_time_injury": "Lost-time injury",
    "next_service_due": "Next service due", "last_service": "Last service", "days_to_service": "Days to service",
    "service_interval_days": "Service interval (days)", "risk_score": "Risk score", "risk_points": "Risk points",
    "condition_message": "Condition message", "priority_score": "Priority score",
}

# short console codes shown above each page title
PAGE_CODES = {"Dashboard": "01", "Worker safety": "02", "Incidents": "03", "Equipment": "04", "Maintenance": "05",
              "Risk assessment": "06", "Alerts": "07", "Data analysis": "08", "Reports": "09", "User management": "10"}


# ===============================================================
# 2. HELPER FUNCTIONS
# ===============================================================
def page_header(title, subtitle=""):
    code = ""
    for name in PAGE_CODES:
        if title.lower().startswith(name.lower().split()[0]):
            code = PAGE_CODES[name]
    stamp = core.TODAY.strftime("%d %b %Y").upper()
    st.markdown('<div class="ph"><div><div class="code">KHWEZI // CONSOLE ' + code + '</div>'
                '<div class="title">' + title + '</div><div class="sub">' + subtitle + '</div></div>'
                '<div class="clock">● LIVE · ' + stamp + '</div></div>', unsafe_allow_html=True)


def section(title):
    st.markdown('<div class="section-title">' + title + '</div>', unsafe_allow_html=True)


def show_tiles(tiles):
    # tiles is a list of (label, value, small text, tone). tone can be left out.
    columns = st.columns(len(tiles))
    for column, tile in zip(columns, tiles):
        label = tile[0]
        value = tile[1]
        small_text = tile[2]
        tone = "neutral"
        if len(tile) > 3:
            tone = tile[3]
        html = ('<div class="tile" style="--c:' + TONE_COLORS[tone] + '"><div class="tile-label">' + str(label) + '</div>'
                '<div class="tile-value">' + str(value) + '</div><div class="tile-sub">' + str(small_text) + '</div></div>')
        column.markdown(html, unsafe_allow_html=True)


def show_banner(text, tone):
    st.markdown('<div class="banner banner-' + tone + '">' + text + '</div>', unsafe_allow_html=True)


def pill(text):
    colour = LEVEL_COLORS.get(text, MUTED)
    return '<span class="pill" style="--c:' + colour + '">' + str(text) + '</span>'


def flash(message):
    # Remembers a message to show after the page reloads
    st.session_state["flash"] = message


def column_name(name):
    if name in COLUMN_NAMES:
        return COLUMN_NAMES[name]
    if "_" in name or name.islower():
        return name.replace("_", " ").capitalize()
    return name


def colour_cell(value):
    colour = LEVEL_COLORS.get(value)
    if colour is None:
        return ""
    return "background-color:" + colour + "26;color:" + colour + ";font-weight:700"


def show_table(df, level_columns=[], height="auto"):
    # Shows a table. Columns in level_columns are coloured (Critical = red, etc.)
    df = df.copy()
    for column in df.columns:
        if pd.api.types.is_datetime64_any_dtype(df[column]):
            df[column] = df[column].dt.strftime("%Y-%m-%d")

    new_names = {}
    for column in df.columns:
        new_names[column] = column_name(column)
    df = df.rename(columns=new_names)

    coloured = []
    for column in level_columns:
        if column in new_names:
            coloured.append(new_names[column])

    if len(coloured) > 0:
        table = df.style.map(colour_cell, subset=coloured)
    else:
        table = df
    st.dataframe(table, hide_index=True, width="stretch", height=height)


def show_chart(fig, key, height=330):
    fig.update_layout(
        height=height, margin=dict(l=10, r=10, t=52, b=10), paper_bgcolor=PANEL, plot_bgcolor=PANEL,
        font=dict(family="Inter, sans-serif", size=12, color=MUTED),
        title=dict(font=dict(family="JetBrains Mono, monospace", size=15, color=INK), x=0.02),
        legend=dict(orientation="h", y=-0.2, title=None, font=dict(color=INK)),
        hoverlabel=dict(bgcolor=RAISED, bordercolor=LINE, font=dict(color=INK)),
    )
    fig.update_xaxes(gridcolor=LINE, zeroline=False, linecolor=LINE)
    fig.update_yaxes(gridcolor=LINE, zeroline=False, linecolor=LINE)
    with st.container(border=True):
        st.plotly_chart(fig, width="stretch", key=key)


def draw_analysis_chart(chart, table, key):
    # Draws the chart that goes with an analysis answer
    if chart["kind"] == "bar" and chart.get("h"):
        fig = px.bar(table, x=chart["x"], y=chart["y"], orientation="h", title=chart["title"],
                     color_discrete_sequence=[AMBER])
        fig.update_yaxes(autorange="reversed")
    elif chart["kind"] == "bar":
        fig = px.bar(table, x=chart["x"], y=chart["y"], title=chart["title"], color_discrete_sequence=[AMBER])
    elif chart["kind"] == "pie":
        fig = px.pie(table, names=chart["x"], values=chart["y"], hole=0.62, title=chart["title"],
                     color=chart["x"], color_discrete_map=CONDITION_COLORS)
        fig.update_traces(marker=dict(line=dict(color=PANEL, width=3)))
    else:
        fig = px.scatter(table, x=chart["x"], y=chart["y"], text=chart.get("label"), title=chart["title"],
                         color_discrete_sequence=[AMBER])
        fig.update_traces(textposition="top center", marker=dict(size=13))
    show_chart(fig, key)


def risk_matrix_chart(risks):
    # 5 x 5 risk matrix showing how many open risks sit in each box
    risks = risks[risks["status"] != "Closed"]
    numbers = [1, 2, 3, 4, 5]
    colour_index = []   # 0 = Low, 1 = Medium, 2 = High, 3 = Critical
    counts = []
    for likelihood in numbers:
        index_row = []
        count_row = []
        for consequence in numbers:
            index_row.append(["Low", "Medium", "High", "Critical"].index(core.classify_risk(likelihood * consequence)))
            how_many = len(risks[(risks["likelihood"] == likelihood) & (risks["consequence"] == consequence)])
            if how_many > 0:
                count_row.append(str(how_many))
            else:
                count_row.append("")
        colour_index.append(index_row)
        counts.append(count_row)

    colour_scale = [[0, "#1F5F45"], [0.249, "#1F5F45"], [0.25, "#24507A"], [0.499, "#24507A"],
                    [0.5, "#8A5A12"], [0.749, "#8A5A12"], [0.75, "#8C2B2B"], [1, "#8C2B2B"]]
    fig = go.Figure(go.Heatmap(z=colour_index, x=numbers, y=numbers, text=counts, texttemplate="<b>%{text}</b>",
                               textfont=dict(color=INK, size=15),
                               zmin=0, zmax=3, colorscale=colour_scale, showscale=False, xgap=4, ygap=4,
                               hovertemplate="Likelihood %{y}, consequence %{x}<extra></extra>"))
    fig.update_layout(title="Open risks on the risk matrix", xaxis_title="Consequence", yaxis_title="Likelihood")
    fig.update_xaxes(dtick=1, showgrid=False)
    fig.update_yaxes(dtick=1, showgrid=False)
    return fig


def gauge(value, title, target, suffix="%"):
    # A dial for one percentage KPI with a marker at the target
    colour = GREEN if value >= target else AMBER
    fig = go.Figure(go.Indicator(
        mode="gauge+number", value=value, number=dict(suffix=suffix, font=dict(family="JetBrains Mono", size=34, color=INK)),
        title=dict(text=title, font=dict(family="JetBrains Mono, monospace", size=13, color=INK)),
        gauge=dict(axis=dict(range=[0, 100], tickcolor=MUTED, tickfont=dict(color=MUTED)), bar=dict(color=colour, thickness=0.28),
                   bgcolor=RAISED, borderwidth=0,
                   steps=[dict(range=[0, target], color="#1A2430"), dict(range=[target, 100], color="#16302A")],
                   threshold=dict(line=dict(color=INK, width=3), thickness=0.8, value=target))))
    return fig


def alert_cards(alerts, limit):
    # Shows alerts as coloured cards instead of a table
    html = ""
    for index, alert in alerts.head(limit).iterrows():
        colour = LEVEL_COLORS[alert["level"]]
        html = html + ('<div class="acard" style="--c:' + colour + '"><div class="bar"></div><div>'
                       '<div class="h">' + pill(alert["level"]) + alert["category"] + " · " + alert["subject"] + " · "
                       + alert["parameter"] + " = " + alert["value"] + '</div>'
                       '<div class="m">' + alert["status"] + " → " + alert["action"] + '</div></div></div>')
    st.markdown(html, unsafe_allow_html=True)


def shift_from_time(time):
    # 06:00-13:59 Day, 14:00-21:59 Afternoon, otherwise Night
    if datetime.time(6, 0) <= time < datetime.time(14, 0):
        return "Day"
    elif datetime.time(14, 0) <= time < datetime.time(22, 0):
        return "Afternoon"
    else:
        return "Night"


def sees_safety(role):
    return core.can(role, "Safety incidents") or core.can(role, "Worker safety data")


# ===============================================================
# 3. LOGIN PAGE
# ===============================================================
LOGIN_CSS = """
<style>
@import url('https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600&family=Barlow+Condensed:wght@500;600;700&display=swap');
/* the front page keeps the original light Khwezi look; every other page stays dark */
[data-testid='stSidebar'], [data-testid='stSidebarCollapsedControl'] { display: none; }
.stApp, [data-testid="stAppViewContainer"], header[data-testid="stHeader"] { background: #F2F3EF !important; }
.stApp:before { display: none; }
.stApp, .stApp p, .stApp label, .stApp [data-testid="stWidgetLabel"] p { font-family: 'Barlow', sans-serif; color: #17262B !important; }
.login-title { font-family: 'Barlow Condensed', sans-serif; font-weight: 600; font-size: 1.45rem; color: #17262B; margin: 2.5rem 0 .4rem; }
.hero { border-radius: 4px; min-height: 540px; padding: 48px 44px; color: #F2F3EF; position: relative;
  background: linear-gradient(168deg, transparent 0 60%, #B5622A 60% 62%, transparent 62% 68%, #D8A93B 68% 69.5%,
  transparent 69.5% 74%, #1F6F7A 74% 80%, #17404D 80% 100%), #0F2A33; }
.hero .name { font-family: 'Barlow Condensed', sans-serif; font-weight: 700; font-size: 4.2rem; line-height: .95; color: #F2F3EF; }
.hero .name span { display: block; color: #D8A93B; font-weight: 500; }
.hero p { max-width: 30rem; font-size: 1.1rem; margin-top: 22px; color: #D5E0E3 !important; }
.hero ul { margin-top: 12px; padding-left: 1.1rem; color: #D5E0E3; }
.hero ul li { margin-bottom: 4px; color: #D5E0E3; }
[data-testid="stForm"] { background: #F2F3EF !important; border: 1px solid #D9DDD5 !important; border-radius: 6px; }
.stApp input { background: #E5E8E3 !important; color: #17262B !important; border: none !important; }
.stApp [data-testid="stTextInputRootElement"], .stApp [data-baseweb="input"], .stApp [data-baseweb="base-input"] {
  background: #E5E8E3 !important; border-color: #E5E8E3 !important; }
.stApp [data-testid="stTextInputRootElement"]:focus-within { border-color: #B5622A !important; }
.stApp [data-testid="stTextInputRootElement"] button, .stApp [data-testid="stTextInputRootElement"] button:hover {
  background: #E5E8E3 !important; border: none !important; }
.stApp [data-testid="stTextInputRootElement"] button, .stApp [data-testid="stTextInputRootElement"] button * { color: #17262B !important; opacity: 1 !important; }
.stApp [data-testid="stTextInputRootElement"] svg path { fill: #17262B !important; }
.stApp button[kind="primaryFormSubmit"], .stApp [data-testid="stBaseButton-primaryFormSubmit"] {
  background: #B5622A !important; border-color: #B5622A !important; color: #FFFFFF !important; }
.stApp button[kind="primaryFormSubmit"] p, .stApp [data-testid="stBaseButton-primaryFormSubmit"] p { color: #FFFFFF !important; }
.stApp [data-testid="stExpander"] details { background: #F2F3EF !important; border: 1px solid #D9DDD5 !important; }
.stApp [data-testid="stExpander"] summary, .stApp [data-testid="stExpander"] summary * { color: #17262B !important; fill: #17262B !important; }
.stApp [data-testid="stCaptionContainer"] p { color: #4B5E64 !important; }
.stApp [data-testid="stToolbar"] button, .stApp [data-testid="stToolbar"] a { background: transparent !important; color: #17262B !important; }
.stApp [data-testid="stToolbar"] svg { color: #17262B !important; }
</style>
"""


def login_page():
    # the original Khwezi front page (light design); the rest of the app uses the dark theme
    st.markdown(LOGIN_CSS, unsafe_allow_html=True)
    left, right = st.columns([1.25, 1], gap="large")

    with left:
        st.markdown(
            '<div class="hero"><div class="name">Khwezi Mining<span>Health And Safety</span></div>'
            "<p>One place to see worker safety, incidents, equipment condition and maintenance, "
            "with alerts when something crosses a limit.</p>"
            "<ul><li>Role-based access for five types of user</li>"
            "<li>Alerts on temperature, vibration, PPE, fatigue and overdue services</li>"
            "<li>Risk scoring and answers to engineering questions</li></ul></div>",
            unsafe_allow_html=True)

    with right:
        st.markdown('<div class="login-title">Sign in</div>', unsafe_allow_html=True)
        with st.form("login_form"):
            username = st.text_input("Username")
            password = st.text_input("Password", type="password")
            submitted = st.form_submit_button("Sign in", type="primary")

        if submitted:
            if username == "" or password == "":
                st.error("Enter both a username and a password.")
            else:
                user = core.login(username, password)
                if user is None:
                    st.error("The username or password is incorrect.")
                else:
                    st.session_state["user"] = user
                    st.rerun()

        with st.expander("Prototype accounts"):
            st.caption("These accounts are for demonstration only.")
            accounts = pd.DataFrame(DEFAULT_USERS, columns=["Username", "Name", "Role", "Password"])
            st.table(accounts.drop(columns="Name"))

# ===============================================================
# 4. PAGES
# ===============================================================
# Every page function receives the same five things:
#   data          the four tables (workers, incidents, equipment, risks)
#   user          the signed-in user (name, role)
#   days          the number of days in the chosen incident period
#   period_label  the text of the chosen period
#   alerts        the alerts this user is allowed to see


# ---------------------------------------------------------------
# Dashboard ("Shift Pulse")
# ---------------------------------------------------------------
def page_dashboard(data, user, days, period_label, alerts):
    role = user["role"]
    page_header("Dashboard · Shift Pulse", "Live operations overview. Incident figures cover: " + period_label.lower())

    # ---- alert status lamps ----
    critical = len(alerts[alerts["level"] == "CRITICAL"])
    warnings = len(alerts[alerts["level"] == "WARNING"])
    total = critical + warnings
    if critical > 0:
        state, state_colour = "ACTION REQUIRED · open the Alerts page", RED
    elif warnings > 0:
        state, state_colour = "MONITOR · warnings only", AMBER
    else:
        state, state_colour = "ALL CLEAR · no active alerts", GREEN
    crit_width = 0
    if total > 0:
        crit_width = round(critical / total * 100)
    st.markdown(
        '<div class="lamps">'
        '<div class="lamp" style="--c:' + RED + '"><div class="dot"></div><div><div class="n">' + str(critical) + '</div><div class="t">Critical alerts</div></div></div>'
        '<div class="lamp" style="--c:' + AMBER + '"><div class="dot"></div><div><div class="n">' + str(warnings) + '</div><div class="t">Warnings</div></div></div>'
        '<div class="lamp" style="--c:' + state_colour + '"><div class="dot"></div><div style="flex:1"><div class="t">System status</div>'
        '<div style="font-family:JetBrains Mono,monospace;font-weight:700;color:' + state_colour + '">' + state + '</div>'
        '<div class="meter"><div style="width:' + str(crit_width) + '%;background:' + RED + '"></div>'
        '<div style="flex:1;background:' + AMBER + '"></div></div></div></div></div>', unsafe_allow_html=True)

    incidents = core.filter_period(data["incidents"], days)
    equipment = core.add_equipment_columns(data["equipment"])

    # ---- health and safety tiles ----
    if sees_safety(role):
        section("Health and safety")
        k = core.safety_kpis(data, days)

        incident_tone = "neutral"
        if k["critical_incidents"] > 0:
            incident_tone = "crit"
        near_miss_tone = "ok"
        if k["near_misses"] > 0:
            near_miss_tone = "warn"
        risk_tone = "ok"
        if k["high_risk_obs"] > 0:
            risk_tone = "crit"
        ppe_tone = "warn"
        if k["ppe_compliance"] >= PPE_TARGET:
            ppe_tone = "ok"

        show_tiles([
            ("Total workers", k["total_workers"], "On the register"),
            ("Safety incidents", k["total_incidents"], str(k["critical_incidents"]) + " critical, " + str(k["lti"]) + " lost-time", incident_tone),
            ("Near misses", k["near_misses"], "Reported by workers", near_miss_tone),
            ("High-risk observations", k["high_risk_obs"], "Open, score 10 or more", risk_tone),
            ("PPE compliance", str(k["ppe_compliance"]) + "%", "Target " + str(round(PPE_TARGET)) + "%", ppe_tone),
        ])

    # ---- equipment tiles ----
    if core.can(role, "Equipment data"):
        section("Equipment fleet")
        k = core.equipment_kpis(data)

        alert_tone = "ok"
        if k["equipment_alerts"] > 0:
            alert_tone = "warn"
        avail_tone = "warn"
        if k["avg_availability"] >= LOW_AVAILABILITY:
            avail_tone = "ok"
        critical_tone = "ok"
        if k["critical_equipment"] > 0:
            critical_tone = "crit"

        show_tiles([
            ("Total equipment", k["total_equipment"], "Monitored units"),
            ("Equipment available", k["available"], "Not in the workshop", "ok"),
            ("Under maintenance", k["under_maintenance"], "In the workshop", "accent"),
            ("Equipment alerts", k["equipment_alerts"], "Warning or critical condition", alert_tone),
            ("Average availability", str(k["avg_availability"]) + "%", "Low below " + str(round(LOW_AVAILABILITY)) + "%", avail_tone),
            ("Critical equipment alerts", k["critical_equipment"], "Inspection required", critical_tone),
        ])

    # ---- gauges ----
    dials = []
    if sees_safety(role):
        dials.append(gauge(core.safety_kpis(data, days)["ppe_compliance"], "PPE COMPLIANCE", PPE_TARGET))
    if core.can(role, "Equipment data"):
        k = core.equipment_kpis(data)
        dials.append(gauge(k["avg_availability"], "FLEET AVAILABILITY", LOW_AVAILABILITY))
        dials.append(gauge(k["pct_normal"], "UNITS OPERATING NORMALLY", 80))
    if len(dials) > 0:
        section("Performance dials")
        columns = st.columns(len(dials))
        for number in range(len(dials)):
            with columns[number]:
                show_chart(dials[number], "dash_dial_" + str(number), height=230)

    # ---- safety charts ----
    if core.can(role, "Safety incidents") and len(incidents) > 0:
        section("Incident intelligence")
        monthly = incidents.copy()
        monthly["month"] = monthly["date"].dt.to_period("M").dt.to_timestamp()
        monthly = monthly.groupby(["month", "severity"]).size().reset_index(name="Incidents")
        fig = px.area(monthly, x="month", y="Incidents", color="severity", title="Incidents per month by severity",
                      color_discrete_map=SEVERITY_COLORS, category_orders={"severity": SEVERITIES})
        fig.update_traces(line=dict(width=1.5))
        fig.update_xaxes(title=None)

        grid = incidents.groupby(["shift", "severity"]).size().unstack(fill_value=0)
        grid = grid.reindex(index=SHIFTS, columns=SEVERITIES, fill_value=0)
        heat = go.Figure(go.Heatmap(z=grid.values, x=SEVERITIES, y=SHIFTS, text=grid.values, texttemplate="<b>%{text}</b>",
                                    colorscale=[[0, RAISED], [0.5, "#8A5A12"], [1, RED]], showscale=False, xgap=4, ygap=4,
                                    textfont=dict(color=INK, size=14),
                                    hovertemplate="%{y} shift, %{x}: %{z} incidents<extra></extra>"))
        heat.update_layout(title="Shift × severity heat map")
        heat.update_xaxes(showgrid=False)
        heat.update_yaxes(showgrid=False)

        left, right = st.columns([1.6, 1])
        with left:
            show_chart(fig, "dash_monthly")
        with right:
            show_chart(heat, "dash_heat")

        counts = incidents["department"].value_counts().sort_values()
        lolly = go.Figure()
        for department, value in counts.items():
            lolly.add_trace(go.Scatter(x=[0, value], y=[department, department], mode="lines",
                                       line=dict(color=LINE, width=4), showlegend=False, hoverinfo="skip"))
        lolly.add_trace(go.Scatter(x=counts.values, y=counts.index, mode="markers+text", text=counts.values,
                                   textposition="middle right", marker=dict(size=16, color=AMBER), showlegend=False,
                                   hovertemplate="%{y}: %{x} incidents<extra></extra>"))
        lolly.update_layout(title="Incidents by department")
        lolly.update_xaxes(title=None, range=[0, counts.max() * 1.18])
    else:
        lolly = None

    # ---- equipment and risk charts ----
    figures = []
    if lolly is not None:
        figures.append(lolly)
    if core.can(role, "Equipment data"):
        counts = equipment["condition"].value_counts()
        by_condition = pd.DataFrame({"Condition": counts.index, "Units": counts.values})
        fig = px.pie(by_condition, names="Condition", values="Units", hole=0.62, title="Equipment condition",
                     color="Condition", color_discrete_map=CONDITION_COLORS)
        fig.update_traces(marker=dict(line=dict(color=PANEL, width=3)), textfont=dict(color=BG))
        normal = int((equipment["condition"] == "Normal").sum())
        fig.add_annotation(text="<b>" + str(normal) + "/" + str(len(equipment)) + "</b><br>normal", showarrow=False,
                           font=dict(family="JetBrains Mono", size=16, color=INK))
        figures.append(fig)

        by_type = equipment.groupby("equipment_type")["availability_pct"].mean().round(1).sort_values().reset_index()
        by_type.columns = ["Type", "Availability (%)"]
        colours = []
        for value in by_type["Availability (%)"]:
            colours.append(RED if value < LOW_AVAILABILITY else TEAL)
        fig = go.Figure(go.Bar(x=by_type["Availability (%)"], y=by_type["Type"], orientation="h", marker_color=colours,
                               text=by_type["Availability (%)"], textposition="outside"))
        fig.add_vline(x=LOW_AVAILABILITY, line_dash="dash", line_color=AMBER)
        fig.update_layout(title="Average availability by type")
        fig.update_traces(cliponaxis=False)
        fig.update_xaxes(range=[60, 104])
        figures.append(fig)

    if core.can(role, "Risk assessment"):
        figures.append(risk_matrix_chart(core.add_risk_columns(data["risks"])))

    if len(figures) > 0:
        section("Fleet and risk")
        number = 0
        for start in range(0, len(figures), 2):
            left, right = st.columns(2)
            with left:
                show_chart(figures[start], "dash_" + str(number))
            number = number + 1
            if start + 1 < len(figures):
                with right:
                    show_chart(figures[start + 1], "dash_" + str(number))
                number = number + 1

    # ---- most urgent alerts ----
    section("Most urgent alerts")
    if len(alerts) == 0:
        st.info("There are no active alerts for your role.")
    else:
        alert_cards(alerts, 8)



# ---------------------------------------------------------------
# Worker safety
# ---------------------------------------------------------------
def page_workers(data, user, days, period_label, alerts):
    role = user["role"]
    page_header("Worker health and safety", "Monitor PPE compliance, fatigue, training and risk for each worker.")
    workers = core.add_worker_columns(data["workers"])

    average_ppe = workers["ppe_compliance_pct"].mean()
    ppe_tone = "warn"
    if average_ppe >= PPE_TARGET:
        ppe_tone = "ok"
    show_tiles([
        ("Workers", len(workers), "On the register"),
        ("Average PPE compliance", str(round(average_ppe, 1)) + "%", "Target " + str(round(PPE_TARGET)) + "%", ppe_tone),
        ("High fatigue", len(workers[workers["fatigue_level"] >= FATIGUE_HIGH]), "Level " + str(FATIGUE_HIGH) + " or more of 10", "warn"),
        ("Training expired", len(workers[workers["training_status"] == "Expired"]), "Needs re-training", "crit"),
        ("High or critical risk", len(workers[workers["risk_level"].isin(["High", "Critical"])]), "Workers", "crit"),
    ])

    tab_names = ["Worker register", "Charts"]
    if core.can_edit(role, "Worker safety data"):
        tab_names.append("Add worker")
    tabs = st.tabs(tab_names)

    # ---- tab 1: register ----
    with tabs[0]:
        c1, c2, c3 = st.columns(3)
        departments = c1.multiselect("Department", DEPARTMENTS)
        shifts = c2.multiselect("Shift", SHIFTS)
        levels = c3.multiselect("Risk level", ["Low", "Medium", "High", "Critical"])

        shown = workers
        if len(departments) > 0:
            shown = shown[shown["department"].isin(departments)]
        if len(shifts) > 0:
            shown = shown[shown["shift"].isin(shifts)]
        if len(levels) > 0:
            shown = shown[shown["risk_level"].isin(levels)]

        show_table(shown.drop(columns="risk_points"), ["risk_level"], height=380)

        unsafe = shown[shown["risk_level"].isin(["High", "Critical"])].sort_values("risk_points", ascending=False)
        section("Unsafe conditions (" + str(len(unsafe)) + ")")
        if len(unsafe) == 0:
            st.success("No workers in the current view are at high or critical risk.")
        for index, worker in unsafe.iterrows():
            message = ("**" + worker["worker_id"] + "** (" + worker["department"] + ", " + worker["shift"]
                       + " shift): " + worker["warnings"] + ".")
            if worker["risk_level"] == "Critical":
                st.error(message)
            else:
                st.warning(message)

    # ---- tab 2: charts ----
    with tabs[1]:
        left, right = st.columns(2)
        with left:
            fig = px.histogram(workers, x="fatigue_level", nbins=10, title="Fatigue level distribution",
                               color_discrete_sequence=[AMBER])
            fig.update_xaxes(title="Fatigue level (1-10)")
            show_chart(fig, "workers_fatigue")
        with right:
            fig = px.box(workers, x="department", y="ppe_compliance_pct", title="PPE compliance by department",
                         color_discrete_sequence=[TEAL])
            fig.update_xaxes(title=None)
            fig.update_yaxes(title="PPE compliance (%)")
            show_chart(fig, "workers_ppe")

        level_counts = []
        for level in ["Low", "Medium", "High", "Critical"]:
            level_counts.append(len(workers[workers["risk_level"] == level]))
        by_level = pd.DataFrame({"Risk level": ["Low", "Medium", "High", "Critical"], "Workers": level_counts})
        fig = px.bar(by_level, x="Risk level", y="Workers", title="Workers by risk level", color="Risk level",
                     color_discrete_map=SEVERITY_COLORS)
        show_chart(fig, "workers_risk")

    # ---- tab 3: add worker ----
    if core.can_edit(role, "Worker safety data"):
        with tabs[2]:
            raw = data["workers"]
            new_id = core.next_id(raw["worker_id"], "WK-")
            with st.form("add_worker", clear_on_submit=True):
                st.caption("New worker ID: " + new_id)
                c1, c2, c3 = st.columns(3)
                department = c1.selectbox("Department", DEPARTMENTS)
                all_roles = []
                for department_roles in JOB_ROLES.values():
                    for role_name in department_roles:
                        if role_name not in all_roles:
                            all_roles.append(role_name)
                job_role = c2.selectbox("Job role", sorted(all_roles))
                shift = c3.selectbox("Shift", SHIFTS)

                c1, c2, c3 = st.columns(3)
                ppe = c1.slider("PPE compliance (%)", 0, 100, 90)
                training = c2.selectbox("Safety training status", TRAINING_STATUS)
                fatigue = c3.slider("Fatigue level (1-10)", 1, 10, 4)

                c1, c2, c3 = st.columns(3)
                observations = c1.number_input("Safety observations", 0, 100, 0)
                near_misses = c2.number_input("Near misses", 0, 100, 0)
                previous = c3.number_input("Previous incidents", 0, 50, 0)
                submitted = st.form_submit_button("Add worker", type="primary")

            if submitted:
                new_row = {"worker_id": new_id, "department": department, "job_role": job_role, "shift": shift,
                           "ppe_compliance_pct": ppe, "training_status": training, "fatigue_level": fatigue,
                           "safety_observations": observations, "near_misses": near_misses,
                           "previous_incidents": previous}
                core.save_table("workers", pd.concat([raw, pd.DataFrame([new_row])], ignore_index=True))
                checked = core.add_worker_columns(pd.DataFrame([new_row])).iloc[0]
                message = "Worker " + new_id + " added. Risk level: " + checked["risk_level"] + "."
                if checked["warnings"] != "":
                    message = message + " Warnings: " + checked["warnings"] + "."
                flash(message)
                st.rerun()


# ---------------------------------------------------------------
# Incidents
# ---------------------------------------------------------------
def page_incidents(data, user, days, period_label, alerts):
    role = user["role"]
    page_header("Safety incident database", "Showing incidents for: " + period_label.lower())
    incidents = core.filter_period(data["incidents"], days)

    show_tiles([
        ("Incidents", len(incidents), "In the selected period"),
        ("High or critical", len(incidents[incidents["severity"].isin(["High", "Critical"])]), "By severity", "crit"),
        ("Lost-time injuries", len(incidents[incidents["lost_time_injury"] == "Yes"]), "Recorded", "warn"),
        ("Not yet closed", len(incidents[incidents["status"] != "Closed"]), "Open or under investigation", "warn"),
    ])

    tab_names = ["Search and filter", "Trends"]
    if core.can_edit(role, "Safety incidents"):
        tab_names.append("Add incident")
    tabs = st.tabs(tab_names)

    # ---- tab 1: search and filter ----
    with tabs[0]:
        search = st.text_input("Search incidents", placeholder="Type a location, type, cause or incident ID")
        c1, c2, c3 = st.columns(3)
        departments = c1.multiselect("Department", DEPARTMENTS, key="inc_department")
        shifts = c2.multiselect("Shift", SHIFTS, key="inc_shift")
        severities = c3.multiselect("Severity", SEVERITIES, key="inc_severity")
        c1, c2 = st.columns(2)
        types = c1.multiselect("Incident type", INCIDENT_TYPES)
        statuses = c2.multiselect("Status", INCIDENT_STATUS)

        shown = incidents
        if search != "":
            # keep a row if the search text appears in any of its columns
            keep = []
            for index, row in shown.iterrows():
                found = False
                for value in row.values:
                    if search.lower() in str(value).lower():
                        found = True
                keep.append(found)
            shown = shown[keep]
        if len(departments) > 0:
            shown = shown[shown["department"].isin(departments)]
        if len(shifts) > 0:
            shown = shown[shown["shift"].isin(shifts)]
        if len(severities) > 0:
            shown = shown[shown["severity"].isin(severities)]
        if len(types) > 0:
            shown = shown[shown["incident_type"].isin(types)]
        if len(statuses) > 0:
            shown = shown[shown["status"].isin(statuses)]

        st.caption(str(len(shown)) + " of " + str(len(incidents)) + " incidents match.")
        show_table(shown.sort_values("date", ascending=False), ["severity"], height=360)
        st.download_button("Download filtered incidents (CSV)", shown.to_csv(index=False), "incidents_filtered.csv", "text/csv")

        # count incidents by a category
        section("Count incidents by category")
        category = st.selectbox("Category", ["department", "shift", "incident_type", "severity", "cause", "status", "location"],
                                format_func=column_name)
        if len(shown) > 0:
            counts = shown[category].value_counts()
            name = column_name(category)
            count_table = pd.DataFrame({name: counts.index, "Incidents": counts.values})
            left, right = st.columns(2)
            with left:
                show_table(count_table)
            with right:
                fig = px.bar(count_table, x="Incidents", y=name, orientation="h", color_discrete_sequence=[AMBER])
                fig.update_yaxes(autorange="reversed", title=None)
                show_chart(fig, "incidents_category")

    # ---- tab 2: trends ----
    with tabs[1]:
        if len(incidents) == 0:
            st.info("There are no incidents in the selected period.")
        else:
            monthly = incidents.copy()
            monthly["month"] = monthly["date"].dt.to_period("M").dt.to_timestamp()
            monthly["is_lti"] = monthly["lost_time_injury"] == "Yes"

            left, right = st.columns(2)
            with left:
                per_month = monthly.groupby("month").size().reset_index(name="Incidents")
                fig = px.line(per_month, x="month", y="Incidents", markers=True, title="Incidents per month",
                              color_discrete_sequence=[AMBER])
                fig.update_xaxes(title=None)
                show_chart(fig, "incidents_trend1")
            with right:
                lti_per_month = monthly.groupby("month")["is_lti"].sum().reset_index(name="Lost-time injuries")
                fig = px.bar(lti_per_month, x="month", y="Lost-time injuries", title="Lost-time injuries per month",
                             color_discrete_sequence=[TEAL])
                fig.update_xaxes(title=None)
                show_chart(fig, "incidents_trend2")

            by_shift = incidents.groupby(["shift", "severity"]).size().reset_index(name="Incidents")
            fig = px.bar(by_shift, x="shift", y="Incidents", color="severity", barmode="group", title="Severity by shift",
                         color_discrete_map=SEVERITY_COLORS, category_orders={"shift": SHIFTS, "severity": SEVERITIES})
            show_chart(fig, "incidents_trend3")

    # ---- tab 3: add incident ----
    if core.can_edit(role, "Safety incidents"):
        with tabs[2]:
            raw = data["incidents"]
            new_id = core.next_id(raw["incident_id"], "INC-" + str(core.TODAY.year) + "-", 4)
            with st.form("add_incident", clear_on_submit=True):
                st.caption("New incident ID: " + new_id + ". The shift is set from the time of the incident.")
                c1, c2, c3 = st.columns(3)
                date = c1.date_input("Date", value=datetime.date.today(), max_value=datetime.date.today())
                time = c2.time_input("Time", value=datetime.time(8, 0))
                department = c3.selectbox("Department", DEPARTMENTS, key="new_incident_department")

                c1, c2, c3 = st.columns(3)
                location = c1.text_input("Location")
                incident_type = c2.selectbox("Incident type", INCIDENT_TYPES, key="new_incident_type")
                severity = c3.selectbox("Severity", SEVERITIES, key="new_incident_severity")

                c1, c2, c3 = st.columns(3)
                injury = c1.selectbox("Injury status", INJURY_STATUS)
                lost_time = c2.selectbox("Lost-time injury", ["No", "Yes"])
                cause = c3.selectbox("Cause", INCIDENT_CAUSES, key="new_incident_cause")

                action = st.text_input("Corrective action", placeholder="Leave empty to use the standard action for the cause")
                status = st.selectbox("Incident status", INCIDENT_STATUS, key="new_incident_status")
                submitted = st.form_submit_button("Add incident", type="primary")

            if submitted:
                # check the inputs before saving
                errors = []
                if location.strip() == "":
                    errors.append("Enter the location of the incident.")
                if lost_time == "Yes" and injury == "No injury":
                    errors.append("A lost-time injury needs an injury status other than 'No injury'.")
                if severity == "Critical" and status == "Closed":
                    errors.append("A critical incident cannot be closed when it is first recorded.")

                if len(errors) > 0:
                    for error in errors:
                        st.error(error)
                else:
                    if action.strip() == "":
                        action = CORRECTIVE_ACTIONS[cause]
                    shift = shift_from_time(time)
                    new_row = {"incident_id": new_id, "date": pd.Timestamp(date), "time": time.strftime("%H:%M"),
                               "shift": shift, "location": location.strip(), "department": department,
                               "incident_type": incident_type, "severity": severity, "injury_status": injury,
                               "lost_time_injury": lost_time, "cause": cause, "corrective_action": action,
                               "status": status}
                    core.save_table("incidents", pd.concat([raw, pd.DataFrame([new_row])], ignore_index=True))
                    message = "Incident " + new_id + " added to the " + shift + " shift."
                    if severity == "Critical" and status != "Closed":
                        message = message + " A critical alert has been raised."
                    flash(message)
                    st.rerun()


# ---------------------------------------------------------------
# Equipment and condition monitoring
# ---------------------------------------------------------------
def page_equipment(data, user, days, period_label, alerts):
    role = user["role"]
    page_header("Equipment and condition monitoring", "Register of mining equipment with temperature and vibration status.")
    equipment = core.add_equipment_columns(data["equipment"])
    k = core.equipment_kpis(data)

    show_tiles([
        ("Total equipment", k["total_equipment"], "Monitored units"),
        ("Operating normally", str(k["pct_normal"]) + "%", "Within limits", "ok"),
        ("Warning or critical", k["equipment_alerts"], "Units", "warn"),
        ("Critical", k["critical_equipment"], "Inspection required", "crit"),
    ])
    st.caption("Prototype thresholds only, not manufacturer or mine safety limits. Temperature: normal below "
               + str(round(TEMP_WARN)) + " °C, warning " + str(round(TEMP_WARN)) + "-" + str(round(TEMP_CRIT))
               + " °C, critical above " + str(round(TEMP_CRIT)) + " °C. Vibration: normal below " + str(round(VIB_WARN))
               + " mm/s, warning " + str(round(VIB_WARN)) + "-" + str(round(VIB_CRIT)) + " mm/s, critical above "
               + str(round(VIB_CRIT)) + " mm/s.")

    can_edit = core.can_edit(role, "Equipment data")
    tab_names = ["Equipment register", "Condition monitoring"]
    if can_edit:
        tab_names = tab_names + ["Update readings", "Add equipment"]
    tabs = st.tabs(tab_names)

    # ---- tab 1: register ----
    with tabs[0]:
        c1, c2, c3 = st.columns(3)
        types = c1.multiselect("Equipment type", list(EQUIPMENT_TYPES))
        departments = c2.multiselect("Department", DEPARTMENTS, key="equipment_department")
        conditions = c3.multiselect("Condition", ["Normal", "Warning", "Critical"])

        shown = equipment
        if len(types) > 0:
            shown = shown[shown["equipment_type"].isin(types)]
        if len(departments) > 0:
            shown = shown[shown["department"].isin(departments)]
        if len(conditions) > 0:
            shown = shown[shown["condition"].isin(conditions)]

        columns = ["equipment_id", "equipment_type", "manufacturer", "department", "location", "operating_hours",
                   "temperature_c", "vibration_mm_s", "fuel_l_per_h", "brake_status", "tyre_status", "engine_status",
                   "maintenance_status", "downtime_h", "availability_pct", "condition"]
        show_table(shown[columns], ["condition"], height=420)

    # ---- tab 2: condition monitoring ----
    with tabs[1]:
        fig = px.scatter(equipment, x="temperature_c", y="vibration_mm_s", color="condition", hover_name="equipment_id",
                         color_discrete_map=CONDITION_COLORS, title="Temperature and vibration by unit",
                         labels={"temperature_c": "Temperature (°C)", "vibration_mm_s": "Vibration (mm/s)", "condition": "Condition"})
        fig.update_traces(marker=dict(size=11, line=dict(width=1, color="white")))
        # dotted lines at the warning and critical limits
        for x_value, y_value in [(TEMP_WARN, VIB_WARN), (TEMP_CRIT, VIB_CRIT)]:
            fig.add_vline(x=x_value, line_dash="dot", line_color="#8A9AA0")
            fig.add_hline(y=y_value, line_dash="dot", line_color="#8A9AA0")
        show_chart(fig, "equipment_scatter")

        section("Units outside normal limits")
        outside = equipment[equipment["condition"] != "Normal"].sort_values(["condition", "vibration_mm_s"], ascending=[True, False])
        show_table(outside[["equipment_id", "equipment_type", "temperature_c", "vibration_mm_s", "condition", "condition_message"]],
                   ["condition"], height=320)

        section("Check a single unit")
        chosen = st.selectbox("Equipment ID", list(equipment["equipment_id"]))
        unit = equipment[equipment["equipment_id"] == chosen].iloc[0]
        if unit["condition"] == "Critical":
            st.error(unit["condition_message"])
        elif unit["condition"] == "Warning":
            st.warning(unit["condition_message"])
        else:
            st.success(unit["condition_message"])

    if can_edit:
        raw = data["equipment"]

        # ---- tab 3: update readings ----
        with tabs[2]:
            with st.form("update_readings"):
                chosen = st.selectbox("Equipment ID", list(raw["equipment_id"]), key="update_id")
                c1, c2, c3 = st.columns(3)
                temperature = c1.number_input("Temperature (°C)", 0.0, 250.0, 70.0, 0.5)
                vibration = c2.number_input("Vibration (mm/s)", 0.0, 50.0, 3.0, 0.1)
                hours = c3.number_input("Hours run since last reading", 0, 500, 0)
                c1, c2, c3 = st.columns(3)
                brake = c1.selectbox("Brake status", ["Good", "Worn", "Replace", "N/A"])
                tyre = c2.selectbox("Tyre status", ["Good", "Worn", "Replace", "N/A"])
                engine = c3.selectbox("Engine status", ["Running normally", "Minor fault", "Major fault"])
                submitted = st.form_submit_button("Save readings", type="primary")

            if submitted:
                row = raw.index[raw["equipment_id"] == chosen][0]
                raw.loc[row, "temperature_c"] = temperature
                raw.loc[row, "vibration_mm_s"] = vibration
                raw.loc[row, "brake_status"] = brake
                raw.loc[row, "tyre_status"] = tyre
                raw.loc[row, "engine_status"] = engine
                raw.loc[row, "operating_hours"] = raw.loc[row, "operating_hours"] + hours
                raw.loc[row, "operating_time_h"] = raw.loc[row, "operating_time_h"] + hours
                condition, message = core.condition_message(temperature, vibration)
                if condition != "Normal":
                    raw.loc[row, "alerts_30d"] = raw.loc[row, "alerts_30d"] + 1
                core.save_table("equipment", raw)
                flash("Readings saved for " + chosen + ". " + message)
                st.rerun()

        # ---- tab 4: add equipment ----
        with tabs[3]:
            with st.form("add_equipment", clear_on_submit=True):
                c1, c2, c3 = st.columns(3)
                equipment_type = c1.selectbox("Equipment type", list(EQUIPMENT_TYPES), key="new_equipment_type")
                manufacturer = c2.text_input("Manufacturer")
                location = c3.selectbox("Location", EQUIPMENT_LOCATIONS)
                c1, c2, c3 = st.columns(3)
                operating_hours = c1.number_input("Operating hours", 0, 200000, 0)
                temperature = c2.number_input("Temperature (°C)", 0.0, 250.0, 60.0, 0.5, key="new_temperature")
                vibration = c3.number_input("Vibration (mm/s)", 0.0, 50.0, 2.0, 0.1, key="new_vibration")
                submitted = st.form_submit_button("Add equipment", type="primary")

            if submitted:
                if manufacturer.strip() == "":
                    st.error("Enter the manufacturer.")
                else:
                    prefix, count, makers, fuel, has_tyres, has_brakes, department = EQUIPMENT_TYPES[equipment_type]
                    same_prefix = raw[raw["equipment_id"].str.startswith(prefix)]
                    new_id = core.next_id(same_prefix["equipment_id"], prefix + "-")
                    brake = "N/A"
                    if has_brakes:
                        brake = "Good"
                    tyre = "N/A"
                    if has_tyres:
                        tyre = "Good"
                    new_row = {"equipment_id": new_id, "equipment_type": equipment_type, "manufacturer": manufacturer.strip(),
                               "department": department, "location": location, "operating_hours": operating_hours,
                               "temperature_c": temperature, "vibration_mm_s": vibration, "fuel_l_per_h": float(fuel),
                               "brake_status": brake, "tyre_status": tyre, "engine_status": "Running normally",
                               "maintenance_status": "In service", "operating_time_h": 0.0, "downtime_h": 0.0,
                               "last_service": core.TODAY, "service_interval_days": 90,
                               "next_service_due": core.TODAY + pd.Timedelta(days=90), "alerts_30d": 0}
                    core.save_table("equipment", pd.concat([raw, pd.DataFrame([new_row])], ignore_index=True))
                    flash("Equipment " + new_id + " added to the register.")
                    st.rerun()


# ---------------------------------------------------------------
# Maintenance
# ---------------------------------------------------------------
def page_maintenance(data, user, days, period_label, alerts):
    role = user["role"]
    page_header("Equipment maintenance monitoring", "Find the units that need service, downtime attention or inspection.")
    equipment = core.add_equipment_columns(data["equipment"])

    st.latex(r"\text{Availability} = \frac{\text{Operating time}}{\text{Operating time} + \text{Downtime}} \times 100")

    # the six maintenance lists
    lists = {
        "Due for maintenance": equipment[equipment["service_state"] == "Due soon"],
        "Overdue": equipment[equipment["service_state"] == "Overdue"],
        "Under maintenance": equipment[equipment["service_state"] == "Under maintenance"],
        "Excessive downtime": equipment[equipment["excessive_downtime"]],
        "Repeated alerts": equipment[equipment["repeated_alerts"]],
        "Low availability": equipment[equipment["low_availability"]],
    }
    small_texts = ["Within " + str(SERVICE_DUE_DAYS) + " days", "Past service date", "In the workshop",
                   str(round(EXCESSIVE_DOWNTIME_H)) + " h or more", str(REPEATED_ALERTS) + " or more in 30 days",
                   "Below " + str(round(LOW_AVAILABILITY)) + "%"]
    tones = ["warn", "crit", "accent", "warn", "warn", "crit"]
    tiles = []
    number = 0
    for name in lists:
        tiles.append((name, len(lists[name]), small_texts[number], tones[number]))
        number = number + 1
    show_tiles(tiles)

    can_edit = core.can_edit(role, "Maintenance data")
    tab_names = ["Maintenance lists", "Availability", "Priority"]
    if can_edit:
        tab_names.append("Log maintenance")
    tabs = st.tabs(tab_names)

    # ---- tab 1: lists ----
    with tabs[0]:
        chosen = st.selectbox("Show", list(lists))
        shown = lists[chosen]
        if len(shown) == 0:
            st.success("No units are in the '" + chosen + "' category.")
        else:
            show_table(shown[["equipment_id", "equipment_type", "service_state", "next_service_due", "days_to_service",
                              "downtime_h", "availability_pct", "alerts_30d", "priority"]], ["service_state", "priority"])

    # ---- tab 2: availability ----
    with tabs[1]:
        lowest_first = equipment.sort_values("availability_pct")
        fig = px.bar(lowest_first, x="equipment_id", y="availability_pct", color="equipment_type",
                     color_discrete_sequence=SEQUENCE, title="Availability by unit (lowest first)",
                     labels={"availability_pct": "Availability (%)", "equipment_id": "", "equipment_type": "Type"})
        fig.add_hline(y=LOW_AVAILABILITY, line_dash="dash", line_color="#B3202F", annotation_text="Low availability limit")
        fig.update_yaxes(range=[60, 100])
        show_chart(fig, "maintenance_availability")

        most_downtime = equipment.sort_values("downtime_h", ascending=False).head(12)
        fig = px.bar(most_downtime, x="equipment_id", y="downtime_h", title="Highest downtime (hours)",
                     color_discrete_sequence=[TEAL], labels={"downtime_h": "Downtime (h)", "equipment_id": ""})
        show_chart(fig, "maintenance_downtime")

    # ---- tab 3: priority ----
    with tabs[2]:
        st.caption("Priority adds points for critical condition, overdue or due service, low availability, excessive "
                   "downtime, repeated alerts and major engine faults.")
        priority = equipment[equipment["priority"] != "Routine"].sort_values("priority_score", ascending=False)
        show_table(priority[["equipment_id", "equipment_type", "priority", "priority_score", "service_state",
                             "condition", "availability_pct"]], ["priority", "service_state", "condition"])

    # ---- tab 4: log maintenance ----
    if can_edit:
        with tabs[3]:
            raw = data["equipment"]
            with st.form("log_maintenance"):
                chosen = st.selectbox("Equipment ID", list(raw["equipment_id"]), key="log_id")
                action = st.radio("Action", ["Start maintenance", "Complete maintenance", "Record downtime"], horizontal=True)
                hours = st.number_input("Downtime hours to add", 0.0, 1000.0, 0.0, 0.5)
                submitted = st.form_submit_button("Save", type="primary")

            if submitted:
                row = raw.index[raw["equipment_id"] == chosen][0]
                if action == "Record downtime" and hours <= 0:
                    st.error("Enter the downtime hours to record.")
                else:
                    if action == "Start maintenance":
                        raw.loc[row, "maintenance_status"] = "Under maintenance"
                        message = chosen + " is now under maintenance."
                    elif action == "Complete maintenance":
                        raw.loc[row, "maintenance_status"] = "In service"
                        raw.loc[row, "alerts_30d"] = 0
                        raw.loc[row, "last_service"] = core.TODAY
                        next_due = core.TODAY + pd.Timedelta(days=int(raw.loc[row, "service_interval_days"]))
                        raw.loc[row, "next_service_due"] = next_due
                        message = "Maintenance completed on " + chosen + ". The next service is due on " + next_due.strftime("%Y-%m-%d") + "."
                    else:
                        message = "Recorded " + str(hours) + " h of downtime for " + chosen + "."
                    raw.loc[row, "downtime_h"] = raw.loc[row, "downtime_h"] + hours
                    core.save_table("equipment", raw)
                    flash(message)
                    st.rerun()


# ---------------------------------------------------------------
# Risk assessment
# ---------------------------------------------------------------
def page_risk(data, user, days, period_label, alerts):
    role = user["role"]
    page_header("Risk assessment", "Risk score = likelihood x consequence, each on a scale of 1 to 5.")
    risks = core.add_risk_columns(data["risks"])

    can_edit = core.can_edit(role, "Risk assessment")
    tab_names = ["Risk calculator", "Risk register"]
    if can_edit:
        tab_names.append("Add risk")
    tabs = st.tabs(tab_names)

    # ---- tab 1: calculator ----
    with tabs[0]:
        left, right = st.columns([1, 1.2])
        with left:
            likelihood = st.slider("Likelihood (1 rare, 5 almost certain)", 1, 5, 3)
            consequence = st.slider("Consequence (1 minor, 5 catastrophic)", 1, 5, 3)
            score = core.risk_score(likelihood, consequence)
            classification = core.classify_risk(score)

            tone = {"Low": "ok", "Medium": "warn", "High": "crit", "Critical": "crit"}[classification]
            show_tiles([("Risk score", score, str(likelihood) + " x " + str(consequence), tone)])
            show_tiles([("Classification", classification, "Low 1-4, Medium 5-9, High 10-16, Critical 17-25", "accent")])

            warning = core.risk_warning(classification)
            if warning is None:
                st.success("Risk is acceptable with the current controls.")
            elif classification == "Critical":
                st.error(warning)
            else:
                st.warning(warning)
        with right:
            show_chart(risk_matrix_chart(risks), "risk_matrix")

    # ---- tab 2: register ----
    with tabs[1]:
        c1, c2, c3 = st.columns(3)
        classes = c1.multiselect("Classification", ["Low", "Medium", "High", "Critical"])
        statuses = c2.multiselect("Status", RISK_STATUS)
        departments = c3.multiselect("Department", DEPARTMENTS, key="risk_department")

        shown = risks
        if len(classes) > 0:
            shown = shown[shown["classification"].isin(classes)]
        if len(statuses) > 0:
            shown = shown[shown["status"].isin(statuses)]
        if len(departments) > 0:
            shown = shown[shown["department"].isin(departments)]
        show_table(shown.sort_values("risk_score", ascending=False), ["classification"], height=420)

    # ---- tab 3: add risk ----
    if can_edit:
        with tabs[2]:
            raw = data["risks"]
            new_id = core.next_id(raw["risk_id"], "RSK-")
            with st.form("add_risk", clear_on_submit=True):
                st.caption("New risk ID: " + new_id)
                hazard = st.text_input("Hazard or observation")
                c1, c2, c3 = st.columns(3)
                department = c1.selectbox("Department", DEPARTMENTS, key="new_risk_department")
                location = c2.text_input("Location")
                owner = c3.selectbox("Owner", ["Safety Officer", "Mining Engineer", "Shift Supervisor"])
                c1, c2, c3 = st.columns(3)
                new_likelihood = c1.slider("Likelihood", 1, 5, 3, key="new_likelihood")
                new_consequence = c2.slider("Consequence", 1, 5, 3, key="new_consequence")
                control = c3.selectbox("Control measure", ["Engineering control", "Administrative control", "PPE",
                                                            "Supervision", "Isolation and lock-out", "Redesign of task"])
                submitted = st.form_submit_button("Add risk", type="primary")

            if submitted:
                if hazard.strip() == "" or location.strip() == "":
                    st.error("Enter both the hazard and the location.")
                else:
                    new_row = {"risk_id": new_id, "date": core.TODAY, "hazard": hazard.strip(), "department": department,
                               "location": location.strip(), "likelihood": new_likelihood, "consequence": new_consequence,
                               "control_measure": control, "owner": owner, "status": "Open"}
                    core.save_table("risks", pd.concat([raw, pd.DataFrame([new_row])], ignore_index=True))
                    new_score = core.risk_score(new_likelihood, new_consequence)
                    new_class = core.classify_risk(new_score)
                    message = "Risk " + new_id + " added: score " + str(new_score) + " (" + new_class + "). "
                    if core.risk_warning(new_class) is not None:
                        message = message + core.risk_warning(new_class)
                    flash(message)
                    st.rerun()


# ---------------------------------------------------------------
# Alerts
# ---------------------------------------------------------------
def page_alerts(data, user, days, period_label, alerts):
    page_header("Alerts and notifications", "Generated automatically from the thresholds and rules in the application.")
    show_tiles([
        ("Critical", len(alerts[alerts["level"] == "CRITICAL"]), "Act now", "crit"),
        ("Warnings", len(alerts[alerts["level"] == "WARNING"]), "Review soon", "warn"),
        ("Categories", alerts["category"].nunique(), "With active alerts"),
    ])

    c1, c2 = st.columns(2)
    levels = c1.multiselect("Level", ["CRITICAL", "WARNING"], default=["CRITICAL", "WARNING"])
    categories = c2.multiselect("Category", sorted(alerts["category"].unique()))

    shown = alerts[alerts["level"].isin(levels)]
    if len(categories) > 0:
        shown = shown[shown["category"].isin(categories)]

    if len(shown) == 0:
        st.success("No alerts match the current filters.")
        return

    show_table(shown[["alert_id", "level", "category", "subject", "parameter", "value", "status"]], ["level"], height=340)

    section("Alert details")
    chosen = st.selectbox("Alert", list(shown["alert_id"]))
    alert = shown[shown["alert_id"] == chosen].iloc[0]
    st.code(core.format_alert(alert), language=None)

    all_text = ""
    for index, one_alert in shown.iterrows():
        all_text = all_text + core.format_alert(one_alert) + "\n\n"
    st.download_button("Download all filtered alerts (text)", all_text, "mining_alerts.txt")


# ---------------------------------------------------------------
# Data analysis
# ---------------------------------------------------------------
def page_analysis(data, user, days, period_label, alerts):
    role = user["role"]
    page_header("Interactive data analysis", "Choose a question and the application answers it from the current data.")

    # keep only the questions this role is allowed to see
    allowed = []
    for question in analysis.QUESTIONS:
        permissions = question[3]
        ok = True
        for permission in permissions:
            if not core.can(role, permission):
                ok = False
        if ok:
            allowed.append(question)

    if len(allowed) == 0:
        st.info("No analysis questions are available for your role.")
        return

    topics = []
    for question in allowed:
        if question[1] not in topics:
            topics.append(question[1])
    topic = st.radio("Topic", topics, horizontal=True)

    questions_in_topic = []
    for question in allowed:
        if question[1] == topic:
            questions_in_topic.append(question)
    texts = []
    for question in questions_in_topic:
        texts.append(question[2])
    chosen_text = st.selectbox("Question", texts)
    question_id = questions_in_topic[texts.index(chosen_text)][0]

    headline, table, chart = analysis.answer_question(question_id, data, days)
    st.markdown('<div class="answer">' + headline + '</div>', unsafe_allow_html=True)

    if table is None:
        return
    if len(table) == 0:
        st.info("Nothing to show for this question right now.")
        return

    colour_columns = []
    for column in table.columns:
        if column in ["priority", "service_state", "condition", "level", "severity"]:
            colour_columns.append(column)

    if chart is not None:
        left, right = st.columns([1.2, 1])
        with left:
            draw_analysis_chart(chart, table, "analysis_chart")
        with right:
            show_table(table, colour_columns, height=330)
    else:
        show_table(table, colour_columns)


# ---------------------------------------------------------------
# Reports
# ---------------------------------------------------------------
def page_reports(data, user, days, period_label, alerts):
    role = user["role"]
    page_header("Reports", "Generate a summary for your role and download the underlying data.")

    if st.button("Generate monitoring report", type="primary"):
        st.session_state["report"] = core.build_report(data, user, days, period_label)

    if "report" in st.session_state:
        st.text_area("Report preview", st.session_state["report"], height=420)
        file_name = "khwezi_report_" + core.TODAY.strftime("%Y%m%d") + ".txt"
        st.download_button("Download report (text)", st.session_state["report"], file_name)

    section("Download data")
    downloads = [("Worker safety data", "workers", "Workers"), ("Safety incidents", "incidents", "Incidents"),
                 ("Equipment data", "equipment", "Equipment"), ("Risk assessment", "risks", "Risk register")]
    columns = st.columns(4)
    for column, download in zip(columns, downloads):
        permission, table_name, label = download
        if core.can(role, permission):
            column.download_button(label + " (CSV)", data[table_name].to_csv(index=False), table_name + ".csv",
                                   "text/csv", key="download_" + table_name)


# ---------------------------------------------------------------
# User management (administrator only)
# ---------------------------------------------------------------
def page_users(data, user, days, period_label, alerts):
    page_header("User management", "Add users, change roles and reset passwords.")
    users = core.load_users()
    administrators = len(users[users["role"] == "Administrator"])

    section("Access permissions by role")
    show_table(core.permission_table())

    section("Users")
    show_table(users[["username", "name", "role"]])

    left, right = st.columns(2)

    # ---- add a user ----
    with left:
        st.markdown("**Add a user**")
        with st.form("add_user", clear_on_submit=True):
            username = st.text_input("Username")
            name = st.text_input("Full name")
            role = st.selectbox("Role", ROLES)
            password = st.text_input("Temporary password", type="password")
            submitted = st.form_submit_button("Add user", type="primary")

        if submitted:
            username = username.strip().lower()
            errors = core.check_new_user(username, name, password)
            if len(errors) > 0:
                for error in errors:
                    st.error(error)
            else:
                core.add_user(username, name, role, password)
                flash("User " + username + " added as " + role + ".")
                st.rerun()

    # ---- manage a user ----
    with right:
        st.markdown("**Manage a user**")
        chosen = st.selectbox("User", list(users["username"]), key="manage_user")
        current_role = users[users["username"] == chosen].iloc[0]["role"]
        new_role = st.selectbox("Role", ROLES, index=ROLES.index(current_role), key="manage_role")

        if st.button("Save role"):
            if current_role == "Administrator" and new_role != "Administrator" and administrators == 1:
                st.error("At least one administrator must remain.")
            else:
                core.change_role(chosen, new_role)
                flash(chosen + " is now " + new_role + ".")
                st.rerun()

        new_password = st.text_input("New password", type="password", key="manage_password")
        if st.button("Reset password"):
            if len(new_password) < 8:
                st.error("Password must be at least 8 characters.")
            else:
                core.change_password(chosen, new_password)
                flash("Password reset for " + chosen + ".")
                st.rerun()

        if st.button("Delete user"):
            if chosen == user["username"]:
                st.error("You cannot delete the account you are signed in with.")
            elif current_role == "Administrator" and administrators == 1:
                st.error("At least one administrator must remain.")
            else:
                core.delete_user(chosen)
                flash("User " + chosen + " deleted.")
                st.rerun()

    # ---- restore the sample data ----
    section("Sample data")
    st.caption("Restore the original synthetic dataset. Records you added will be removed.")
    if st.checkbox("I understand this replaces all current records") and st.button("Restore sample data"):
        core.reset_sample_data()
        flash("Sample data restored.")
        st.rerun()


# ===============================================================
# 5. MAIN: sidebar, navigation and showing the chosen page
# ===============================================================
# (page name, permission needed, function)
PAGES = [
    ("Dashboard", "View dashboard", page_dashboard),
    ("Worker safety", "Worker safety data", page_workers),
    ("Incidents", "Safety incidents", page_incidents),
    ("Equipment", "Equipment data", page_equipment),
    ("Maintenance", "Maintenance data", page_maintenance),
    ("Risk assessment", "Risk assessment", page_risk),
    ("Alerts", "View dashboard", page_alerts),
    ("Data analysis", "View dashboard", page_analysis),
    ("Reports", "Generate reports", page_reports),
    ("User management", "Manage users", page_users),
]


# icon shown next to each page in the sidebar
PAGE_ICONS = {"Dashboard": "◉", "Worker safety": "👷", "Incidents": "📒", "Equipment": "🚜", "Maintenance": "🛠",
              "Risk assessment": "▦", "Alerts": "🚨", "Data analysis": "📊", "Reports": "🗒", "User management": "🔐"}

def main():
    core.make_sure_data_exists()

    # not signed in yet: show the login page
    if "user" not in st.session_state:
        login_page()
        return

    user = st.session_state["user"]
    role = user["role"]

    # the pages this role is allowed to open
    names = []
    for name, permission, function in PAGES:
        if core.can(role, permission):
            names.append(name)

    # ---- sidebar ----
    with st.sidebar:
        st.markdown('<div class="brand"><div class="brand-name">⛏ KHWEZI</div>'
                    '<div class="brand-sub">HEALTH · SAFETY · FLEET</div></div>', unsafe_allow_html=True)
        st.markdown('<div class="usercard"><b>' + user["name"] + '</b><br><span class="role">● ' + role.upper()
                    + '</span></div>', unsafe_allow_html=True)
        choice = st.radio("Navigate", names, label_visibility="collapsed", format_func=lambda name: PAGE_ICONS[name] + "  " + name)
        period_label = st.selectbox("Incident period", list(PERIOD_OPTIONS), index=3)
        if st.button("⏻  Sign out", width="stretch"):
            st.session_state.clear()
            st.rerun()

    # ---- load the data and show the chosen page ----
    days = PERIOD_OPTIONS[period_label]
    data = core.load_data()
    alerts = core.alerts_for_role(core.build_alerts(data), role)

    if "flash" in st.session_state:
        st.success(st.session_state.pop("flash"))

    for name, permission, function in PAGES:
        if name == choice:
            function(data, user, days, period_label, alerts)


main()
